#
# TABLE STRUCTURE FOR: berkas_tbl
#

DROP TABLE IF EXISTS `berkas_tbl`;

CREATE TABLE `berkas_tbl` (
  `berkas_ID` int(11) NOT NULL AUTO_INCREMENT,
  `berkas_jenis` varchar(15) DEFAULT NULL,
  `berkas_nama` varchar(50) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_proker` int(11) DEFAULT NULL,
  `berkas_tanggal` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `berkas_lembaga` int(11) NOT NULL,
  PRIMARY KEY (`berkas_ID`),
  KEY `uploadOleh` (`id_user`),
  KEY `berkasProker` (`id_proker`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=latin1;

INSERT INTO `berkas_tbl` (`berkas_ID`, `berkas_jenis`, `berkas_nama`, `id_user`, `id_proker`, `berkas_tanggal`, `berkas_lembaga`) VALUES (45, 'umum', '13__LAMP_INSTRUMEN_WAWANCARA.docx', 1, 0, '2019-12-15 08:21:18', 1);
INSERT INTO `berkas_tbl` (`berkas_ID`, `berkas_jenis`, `berkas_nama`, `id_user`, `id_proker`, `berkas_tanggal`, `berkas_lembaga`) VALUES (46, 'lpj', 'ABSTRAK_MaulanaRahmanNur.pdf', 1, 0, '2019-12-15 08:21:39', 1);
INSERT INTO `berkas_tbl` (`berkas_ID`, `berkas_jenis`, `berkas_nama`, `id_user`, `id_proker`, `berkas_tanggal`, `berkas_lembaga`) VALUES (47, 'link', 'www.link.com', 1, 0, '2019-12-15 08:21:49', 1);
INSERT INTO `berkas_tbl` (`berkas_ID`, `berkas_jenis`, `berkas_nama`, `id_user`, `id_proker`, `berkas_tanggal`, `berkas_lembaga`) VALUES (48, 'umum', '13__LAMP_INSTRUMEN_WAWANCARA.docx', 1, 5, '2019-12-15 08:22:22', 1);
INSERT INTO `berkas_tbl` (`berkas_ID`, `berkas_jenis`, `berkas_nama`, `id_user`, `id_proker`, `berkas_tanggal`, `berkas_lembaga`) VALUES (49, 'lpj', 'ABSTRAK_MaulanaRahmanNur.pdf', 1, 5, '2019-12-15 08:22:31', 1);
INSERT INTO `berkas_tbl` (`berkas_ID`, `berkas_jenis`, `berkas_nama`, `id_user`, `id_proker`, `berkas_tanggal`, `berkas_lembaga`) VALUES (50, 'link', 'www.google.com', 1, 5, '2019-12-15 08:22:40', 1);


#
# TABLE STRUCTURE FOR: departemen_tbl
#

DROP TABLE IF EXISTS `departemen_tbl`;

CREATE TABLE `departemen_tbl` (
  `departemen_ID` int(11) NOT NULL AUTO_INCREMENT,
  `departemen_nama` varchar(50) NOT NULL,
  `id_opmawa` int(11) NOT NULL,
  PRIMARY KEY (`departemen_ID`),
  KEY `id_opmawa` (`id_opmawa`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `departemen_tbl` (`departemen_ID`, `departemen_nama`, `id_opmawa`) VALUES (4, 'Badan Pengurus Harian', 1);
INSERT INTO `departemen_tbl` (`departemen_ID`, `departemen_nama`, `id_opmawa`) VALUES (5, 'Kesekretariatan', 1);
INSERT INTO `departemen_tbl` (`departemen_ID`, `departemen_nama`, `id_opmawa`) VALUES (6, 'Kaderisasi', 1);
INSERT INTO `departemen_tbl` (`departemen_ID`, `departemen_nama`, `id_opmawa`) VALUES (7, 'Informasi dan Komunikasi', 1);
INSERT INTO `departemen_tbl` (`departemen_ID`, `departemen_nama`, `id_opmawa`) VALUES (8, 'Profesi dan Keilmiahan', 1);
INSERT INTO `departemen_tbl` (`departemen_ID`, `departemen_nama`, `id_opmawa`) VALUES (9, 'Biro Kewirausahaan', 1);
INSERT INTO `departemen_tbl` (`departemen_ID`, `departemen_nama`, `id_opmawa`) VALUES (10, 'Seni dan Keolahragaan', 1);


#
# TABLE STRUCTURE FOR: dosen_tbl
#

DROP TABLE IF EXISTS `dosen_tbl`;

CREATE TABLE `dosen_tbl` (
  `dosen_ID` int(11) NOT NULL AUTO_INCREMENT,
  `dosen_nik` int(20) NOT NULL,
  `dosen_nama` varchar(50) NOT NULL,
  `dosen_password` varchar(25) NOT NULL,
  `id_prodi` int(11) NOT NULL,
  PRIMARY KEY (`dosen_ID`),
  KEY `dosen_prodi` (`id_prodi`),
  CONSTRAINT `dosen_prodi` FOREIGN KEY (`id_prodi`) REFERENCES `prodi_tbl` (`prodi_ID`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

INSERT INTO `dosen_tbl` (`dosen_ID`, `dosen_nik`, `dosen_nama`, `dosen_password`, `id_prodi`) VALUES (31, 1, 'Ini dosen', '1', 6);


#
# TABLE STRUCTURE FOR: evaluasirapat_tbl
#

DROP TABLE IF EXISTS `evaluasirapat_tbl`;

CREATE TABLE `evaluasirapat_tbl` (
  `evaluasiRapat_ID` int(11) NOT NULL AUTO_INCREMENT,
  `id_rapat` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `evaluasiRapat_isi` text NOT NULL,
  PRIMARY KEY (`evaluasiRapat_ID`),
  KEY `evaluasiRapat-rapat` (`id_rapat`),
  KEY `evaluasiRapat-user` (`id_user`),
  CONSTRAINT `evaluasiRapat-rapat` FOREIGN KEY (`id_rapat`) REFERENCES `rapat_tbl` (`rapat_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `evaluasiRapat-user` FOREIGN KEY (`id_user`) REFERENCES `user_tbl` (`user_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `evaluasirapat_tbl` (`evaluasiRapat_ID`, `id_rapat`, `id_user`, `evaluasiRapat_isi`) VALUES (4, 5, 1, 'saya sukaaaa\r\n');


#
# TABLE STRUCTURE FOR: opmawa_tbl
#

DROP TABLE IF EXISTS `opmawa_tbl`;

CREATE TABLE `opmawa_tbl` (
  `opmawa_ID` int(11) NOT NULL AUTO_INCREMENT,
  `opmawa_kabinet` varchar(25) NOT NULL,
  `id_user` int(11) NOT NULL,
  `opmawa_tahun` int(5) NOT NULL,
  PRIMARY KEY (`opmawa_ID`),
  KEY `getKetuaNama` (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `opmawa_tbl` (`opmawa_ID`, `opmawa_kabinet`, `id_user`, `opmawa_tahun`) VALUES (1, 'Bersatu', 1, 2018);
INSERT INTO `opmawa_tbl` (`opmawa_ID`, `opmawa_kabinet`, `id_user`, `opmawa_tahun`) VALUES (4, 'Madani', 28, 2019);
INSERT INTO `opmawa_tbl` (`opmawa_ID`, `opmawa_kabinet`, `id_user`, `opmawa_tahun`) VALUES (5, 'Satu', 1, 2019);


#
# TABLE STRUCTURE FOR: pemasukan_tbl
#

DROP TABLE IF EXISTS `pemasukan_tbl`;

CREATE TABLE `pemasukan_tbl` (
  `pemasukan_ID` int(11) NOT NULL AUTO_INCREMENT,
  `pemasukan_nominal` varchar(15) NOT NULL,
  `pemasukan_deskripsi` varchar(60) NOT NULL,
  `pemasukan_tanggal` date NOT NULL,
  `pemasukan_file` varchar(25) DEFAULT NULL,
  `id_proker` int(5) NOT NULL,
  `pemasukan_lembaga` int(3) NOT NULL,
  `id_opmawa` int(11) NOT NULL,
  PRIMARY KEY (`pemasukan_ID`),
  KEY `OpmawaIDpemasukan` (`id_opmawa`),
  CONSTRAINT `OpmawaIDpemasukan` FOREIGN KEY (`id_opmawa`) REFERENCES `opmawa_tbl` (`opmawa_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=latin1;

INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (33, '100000', 'Dana awal sumbangan panitia', '2019-10-19', NULL, 5, 1, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (35, '80000', 'Pemasukan awal panitia', '2019-11-14', NULL, 6, 2, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (36, '1000', 'Nemu duit dijalan', '2019-11-02', NULL, 6, 2, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (37, '150000', 'test', '2019-11-12', NULL, 6, 2, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (38, '9000', 'test', '0000-00-00', NULL, 6, 2, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (39, '80000', 'hhh', '1111-01-01', NULL, 6, 2, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (40, '10000', 'dana awal', '2019-11-11', NULL, 7, 2, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (41, '10000', 'dana awal', '2019-11-11', NULL, 7, 2, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (42, '', '', '0000-00-00', NULL, 7, 2, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (43, '1000', 'Pemasukan Sekretariat', '2019-12-31', NULL, 0, 1, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (45, '20000', 'duit', '1111-01-01', NULL, 3, 1, 1);


#
# TABLE STRUCTURE FOR: pengeluaran_tbl
#

DROP TABLE IF EXISTS `pengeluaran_tbl`;

CREATE TABLE `pengeluaran_tbl` (
  `pengeluaran_ID` int(11) NOT NULL AUTO_INCREMENT,
  `pengeluaran_nominal` varchar(15) NOT NULL,
  `pengeluaran_deskripsi` varchar(60) NOT NULL,
  `pengeluaran_tanggal` date NOT NULL,
  `pengeluaran_file` varchar(25) DEFAULT NULL,
  `id_proker` int(5) NOT NULL,
  `pengeluaran_lembaga` int(3) NOT NULL,
  `id_opmawa` int(11) NOT NULL,
  PRIMARY KEY (`pengeluaran_ID`),
  KEY `OpmawaID` (`id_opmawa`),
  CONSTRAINT `OpmawaID` FOREIGN KEY (`id_opmawa`) REFERENCES `opmawa_tbl` (`opmawa_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (8, '50000', 'Modal usaha danus', '2019-10-20', '1571419689.jpg', 5, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (9, '300000', 'bayar makanan', '2019-10-15', NULL, 3, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (10, '30000', 'Modal usaha danus', '2019-11-09', NULL, 6, 2, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (11, '500', 'Pengeluaran sekretariat', '2019-12-02', NULL, 0, 1, 1);


#
# TABLE STRUCTURE FOR: posisi_tbl
#

DROP TABLE IF EXISTS `posisi_tbl`;

CREATE TABLE `posisi_tbl` (
  `posisi_ID` int(11) NOT NULL AUTO_INCREMENT,
  `posisi_nama` varchar(25) NOT NULL,
  `posisi_lembaga` int(1) NOT NULL,
  PRIMARY KEY (`posisi_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

INSERT INTO `posisi_tbl` (`posisi_ID`, `posisi_nama`, `posisi_lembaga`) VALUES (1, 'Ketua Umum', 1);
INSERT INTO `posisi_tbl` (`posisi_ID`, `posisi_nama`, `posisi_lembaga`) VALUES (2, 'Ketua Umum', 2);
INSERT INTO `posisi_tbl` (`posisi_ID`, `posisi_nama`, `posisi_lembaga`) VALUES (3, 'Sekretaris Umum', 1);
INSERT INTO `posisi_tbl` (`posisi_ID`, `posisi_nama`, `posisi_lembaga`) VALUES (4, 'Sekretaris Umum', 2);
INSERT INTO `posisi_tbl` (`posisi_ID`, `posisi_nama`, `posisi_lembaga`) VALUES (5, 'Bendahara Umum', 1);
INSERT INTO `posisi_tbl` (`posisi_ID`, `posisi_nama`, `posisi_lembaga`) VALUES (6, 'Bendahara Umum', 2);
INSERT INTO `posisi_tbl` (`posisi_ID`, `posisi_nama`, `posisi_lembaga`) VALUES (7, 'Ketua Departemen', 1);
INSERT INTO `posisi_tbl` (`posisi_ID`, `posisi_nama`, `posisi_lembaga`) VALUES (8, 'Ketua Komisi', 2);
INSERT INTO `posisi_tbl` (`posisi_ID`, `posisi_nama`, `posisi_lembaga`) VALUES (9, 'Sekretaris Departemen', 1);
INSERT INTO `posisi_tbl` (`posisi_ID`, `posisi_nama`, `posisi_lembaga`) VALUES (10, 'Bendahara Departemen', 1);
INSERT INTO `posisi_tbl` (`posisi_ID`, `posisi_nama`, `posisi_lembaga`) VALUES (11, 'Anggota Departemen', 1);
INSERT INTO `posisi_tbl` (`posisi_ID`, `posisi_nama`, `posisi_lembaga`) VALUES (12, 'volunter', 2);


#
# TABLE STRUCTURE FOR: prodi_tbl
#

DROP TABLE IF EXISTS `prodi_tbl`;

CREATE TABLE `prodi_tbl` (
  `prodi_ID` int(11) NOT NULL AUTO_INCREMENT,
  `prodi_nama` varchar(50) NOT NULL,
  PRIMARY KEY (`prodi_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

INSERT INTO `prodi_tbl` (`prodi_ID`, `prodi_nama`) VALUES (1, 'Pendidikan Matematika');
INSERT INTO `prodi_tbl` (`prodi_ID`, `prodi_nama`) VALUES (2, 'Pendidikan Fisika');
INSERT INTO `prodi_tbl` (`prodi_ID`, `prodi_nama`) VALUES (5, 'Matematika');
INSERT INTO `prodi_tbl` (`prodi_ID`, `prodi_nama`) VALUES (6, 'Ilmu Komputer');
INSERT INTO `prodi_tbl` (`prodi_ID`, `prodi_nama`) VALUES (7, 'Statistika');
INSERT INTO `prodi_tbl` (`prodi_ID`, `prodi_nama`) VALUES (8, 'Fisika');
INSERT INTO `prodi_tbl` (`prodi_ID`, `prodi_nama`) VALUES (9, 'Pendidikan Fisika');
INSERT INTO `prodi_tbl` (`prodi_ID`, `prodi_nama`) VALUES (10, 'Biologi');
INSERT INTO `prodi_tbl` (`prodi_ID`, `prodi_nama`) VALUES (11, 'Kimia');
INSERT INTO `prodi_tbl` (`prodi_ID`, `prodi_nama`) VALUES (12, 'Pendidikan Biologi');
INSERT INTO `prodi_tbl` (`prodi_ID`, `prodi_nama`) VALUES (13, 'Pendidikan Kimia');
INSERT INTO `prodi_tbl` (`prodi_ID`, `prodi_nama`) VALUES (18, 'ssssssss');
INSERT INTO `prodi_tbl` (`prodi_ID`, `prodi_nama`) VALUES (19, 'a');
INSERT INTO `prodi_tbl` (`prodi_ID`, `prodi_nama`) VALUES (20, 'cccccc');
INSERT INTO `prodi_tbl` (`prodi_ID`, `prodi_nama`) VALUES (21, 'xxx');
INSERT INTO `prodi_tbl` (`prodi_ID`, `prodi_nama`) VALUES (22, 's');
INSERT INTO `prodi_tbl` (`prodi_ID`, `prodi_nama`) VALUES (23, 'v');


#
# TABLE STRUCTURE FOR: proker_tbl
#

DROP TABLE IF EXISTS `proker_tbl`;

CREATE TABLE `proker_tbl` (
  `proker_ID` int(11) NOT NULL AUTO_INCREMENT,
  `proker_nama` varchar(50) NOT NULL,
  `proker_deskripsi` varchar(250) NOT NULL,
  `proker_tanggal` date DEFAULT NULL,
  `proker_jenis` varchar(10) DEFAULT NULL,
  `proker_lembaga` int(2) NOT NULL,
  `proker_tahun` int(5) NOT NULL,
  `proker_nilai` varchar(5) DEFAULT NULL,
  `proker_output` text,
  PRIMARY KEY (`proker_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`) VALUES (1, 'BINER 4.0', '', '2019-06-18', '0', 1, 2019, '89', NULL);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`) VALUES (2, 'BINER 3.0', '', '2019-06-03', '0', 1, 2017, '100', NULL);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`) VALUES (3, 'BINER 2.0', '', '2019-06-02', '0', 1, 2018, '30', NULL);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`) VALUES (5, 'BINER', 'Seminar tentang teknologi', '2020-09-01', 'event', 1, 2018, '90', 'Program kerja biner merupakan sebuah kegiatan seminar dan workshop yang dapat diikuti oleh berbagai kalangan umum. proker ini berfokus pada pelatihan mengenai pengembangan teknologi');
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`) VALUES (6, 'Bulan Legislatif', 'Mengenalkan tentang legislatif pada mahasiswa fmipa', '2020-03-28', 'event', 2, 2018, NULL, NULL);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`) VALUES (7, 'proker 1', '', '2019-11-08', '0', 2, 2018, NULL, NULL);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`) VALUES (8, 'kpu', '', '2019-11-20', '0', 2, 2018, NULL, NULL);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`) VALUES (9, 'Update', 'untuk coba coba', '0000-00-00', 'non_event', 2, 2018, NULL, NULL);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`) VALUES (10, 'BINER 1.0', 'seminar', '2019-12-27', 'event', 1, 2018, NULL, 'Program kerja biner merupakan sebuah kegiatan seminar dan workshop yang dapat diikuti oleh berbagai kalangan umum. proker ini berfokus pada pelatihan mengenai pengembangan teknologi');


#
# TABLE STRUCTURE FOR: prokeranggota_tbl
#

DROP TABLE IF EXISTS `prokeranggota_tbl`;

CREATE TABLE `prokeranggota_tbl` (
  `prokerAnggota_ID` int(11) NOT NULL AUTO_INCREMENT,
  `id_proker` int(11) NOT NULL,
  `id_posisi` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  PRIMARY KEY (`prokerAnggota_ID`),
  KEY `proker` (`id_proker`),
  KEY `posisi` (`id_posisi`),
  KEY `nama` (`id_user`),
  CONSTRAINT `nama` FOREIGN KEY (`id_user`) REFERENCES `user_tbl` (`user_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `posisi` FOREIGN KEY (`id_posisi`) REFERENCES `prokerposisi_tbl` (`prokerPosisi_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `proker` FOREIGN KEY (`id_proker`) REFERENCES `proker_tbl` (`proker_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

INSERT INTO `prokeranggota_tbl` (`prokerAnggota_ID`, `id_proker`, `id_posisi`, `id_user`) VALUES (17, 2, 29, 28);
INSERT INTO `prokeranggota_tbl` (`prokerAnggota_ID`, `id_proker`, `id_posisi`, `id_user`) VALUES (18, 7, 30, 30);
INSERT INTO `prokeranggota_tbl` (`prokerAnggota_ID`, `id_proker`, `id_posisi`, `id_user`) VALUES (19, 7, 32, 29);
INSERT INTO `prokeranggota_tbl` (`prokerAnggota_ID`, `id_proker`, `id_posisi`, `id_user`) VALUES (20, 8, 34, 29);
INSERT INTO `prokeranggota_tbl` (`prokerAnggota_ID`, `id_proker`, `id_posisi`, `id_user`) VALUES (21, 8, 37, 30);
INSERT INTO `prokeranggota_tbl` (`prokerAnggota_ID`, `id_proker`, `id_posisi`, `id_user`) VALUES (25, 5, 81, 28);


#
# TABLE STRUCTURE FOR: prokerevaluasi_tbl
#

DROP TABLE IF EXISTS `prokerevaluasi_tbl`;

CREATE TABLE `prokerevaluasi_tbl` (
  `prokerEvaluasi_ID` int(11) NOT NULL AUTO_INCREMENT,
  `id_proker` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `prokerEvaluasi_isi` text NOT NULL,
  PRIMARY KEY (`prokerEvaluasi_ID`),
  KEY `proker-prokerEvaluasi` (`id_proker`),
  KEY `user-prokerEvaluasi` (`id_user`),
  CONSTRAINT `proker-prokerEvaluasi` FOREIGN KEY (`id_proker`) REFERENCES `proker_tbl` (`proker_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user-prokerEvaluasi` FOREIGN KEY (`id_user`) REFERENCES `user_tbl` (`user_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (3, 5, 1, 'Jangan lama lama');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (5, 5, 1, 'Kurang banyak yang datang');


#
# TABLE STRUCTURE FOR: prokerposisi_tbl
#

DROP TABLE IF EXISTS `prokerposisi_tbl`;

CREATE TABLE `prokerposisi_tbl` (
  `prokerPosisi_ID` int(11) NOT NULL AUTO_INCREMENT,
  `id_proker` int(3) NOT NULL,
  `prokerPosisi_nama` varchar(25) NOT NULL,
  PRIMARY KEY (`prokerPosisi_ID`),
  KEY `getProker` (`id_proker`),
  CONSTRAINT `getProker` FOREIGN KEY (`id_proker`) REFERENCES `proker_tbl` (`proker_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=latin1;

INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (26, 6, 'Ketua Pelaksana');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (27, 6, 'HPD');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (28, 2, 'Ketua Pelaksana');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (29, 2, 'HPD');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (30, 7, 'Ketua Pelaksana');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (31, 7, 'HPD');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (32, 7, 'perlengkapan');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (33, 7, 'acara');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (34, 8, 'Ketua Pelaksana');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (35, 8, 'acara');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (36, 8, 'adhum');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (37, 8, 'logistik');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (39, 8, 'HPD');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (40, 8, 'sekretaris');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (41, 8, 'bendahara');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (81, 5, 'Ketua Pelaksana');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (82, 5, 'HPD');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (83, 5, 'Administrasi');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (84, 5, 'Perlengkapan');


#
# TABLE STRUCTURE FOR: prokertugas_tbl
#

DROP TABLE IF EXISTS `prokertugas_tbl`;

CREATE TABLE `prokertugas_tbl` (
  `prokerTugas_ID` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `id_proker` int(11) NOT NULL,
  `prokerTugas_deskripsi` varchar(255) NOT NULL,
  `prokerTugas_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`prokerTugas_ID`),
  KEY `namaUser` (`id_user`),
  KEY `namaProker` (`id_proker`),
  CONSTRAINT `namaProker` FOREIGN KEY (`id_proker`) REFERENCES `proker_tbl` (`proker_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=latin1;

INSERT INTO `prokertugas_tbl` (`prokerTugas_ID`, `id_user`, `id_proker`, `prokerTugas_deskripsi`, `prokerTugas_status`) VALUES (37, 1, 5, 'Membuat tema acara yang berkaitan dengan perkuliahan', 1);
INSERT INTO `prokertugas_tbl` (`prokerTugas_ID`, `id_user`, `id_proker`, `prokerTugas_deskripsi`, `prokerTugas_status`) VALUES (41, 1, 5, 'Membuat Kepanitiaan', 1);
INSERT INTO `prokertugas_tbl` (`prokerTugas_ID`, `id_user`, `id_proker`, `prokerTugas_deskripsi`, `prokerTugas_status`) VALUES (42, 0, 1, 'TEst\r\n', 0);
INSERT INTO `prokertugas_tbl` (`prokerTugas_ID`, `id_user`, `id_proker`, `prokerTugas_deskripsi`, `prokerTugas_status`) VALUES (43, 29, 7, 'siapin kamera\r\n', 0);
INSERT INTO `prokertugas_tbl` (`prokerTugas_ID`, `id_user`, `id_proker`, `prokerTugas_deskripsi`, `prokerTugas_status`) VALUES (44, 30, 8, 'minjam ruangan', 0);
INSERT INTO `prokertugas_tbl` (`prokerTugas_ID`, `id_user`, `id_proker`, `prokerTugas_deskripsi`, `prokerTugas_status`) VALUES (45, 30, 8, 'bikin kotak suara', 0);
INSERT INTO `prokertugas_tbl` (`prokerTugas_ID`, `id_user`, `id_proker`, `prokerTugas_deskripsi`, `prokerTugas_status`) VALUES (46, 0, 8, 'print presensi', 0);
INSERT INTO `prokertugas_tbl` (`prokerTugas_ID`, `id_user`, `id_proker`, `prokerTugas_deskripsi`, `prokerTugas_status`) VALUES (47, 0, 5, 'Buat Indomie', 0);
INSERT INTO `prokertugas_tbl` (`prokerTugas_ID`, `id_user`, `id_proker`, `prokerTugas_deskripsi`, `prokerTugas_status`) VALUES (49, 28, 5, 'Testing', 0);


#
# TABLE STRUCTURE FOR: rapat_tbl
#

DROP TABLE IF EXISTS `rapat_tbl`;

CREATE TABLE `rapat_tbl` (
  `rapat_ID` int(11) NOT NULL AUTO_INCREMENT,
  `rapat_tanggal` date NOT NULL,
  `rapat_deskripsi` varchar(100) NOT NULL,
  `rapat_lembaga` int(11) NOT NULL,
  `id_opmawa` int(11) NOT NULL,
  PRIMARY KEY (`rapat_ID`),
  KEY `getOpmawa_rapat` (`id_opmawa`),
  CONSTRAINT `getOpmawa_rapat` FOREIGN KEY (`id_opmawa`) REFERENCES `opmawa_tbl` (`opmawa_ID`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

INSERT INTO `rapat_tbl` (`rapat_ID`, `rapat_tanggal`, `rapat_deskripsi`, `rapat_lembaga`, `id_opmawa`) VALUES (5, '2019-10-28', 'Kumpul Biasa', 1, 1);
INSERT INTO `rapat_tbl` (`rapat_ID`, `rapat_tanggal`, `rapat_deskripsi`, `rapat_lembaga`, `id_opmawa`) VALUES (6, '2019-11-13', 'Rapat progres awal', 2, 1);
INSERT INTO `rapat_tbl` (`rapat_ID`, `rapat_tanggal`, `rapat_deskripsi`, `rapat_lembaga`, `id_opmawa`) VALUES (7, '2019-11-27', 'Rapat penutupan', 2, 1);
INSERT INTO `rapat_tbl` (`rapat_ID`, `rapat_tanggal`, `rapat_deskripsi`, `rapat_lembaga`, `id_opmawa`) VALUES (13, '2020-01-31', 'Rapat internal', 1, 1);


#
# TABLE STRUCTURE FOR: user_tbl
#

DROP TABLE IF EXISTS `user_tbl`;

CREATE TABLE `user_tbl` (
  `user_ID` int(11) NOT NULL AUTO_INCREMENT,
  `user_nama` varchar(25) NOT NULL,
  `user_NIM` varchar(15) NOT NULL,
  `user_pass` varchar(25) NOT NULL,
  `id_prodi` int(2) NOT NULL,
  `id_posisi` int(2) NOT NULL,
  `id_opmawa` int(11) NOT NULL,
  `id_departemen` int(11) NOT NULL,
  `user_tahun` int(4) NOT NULL,
  `user_role` int(1) NOT NULL,
  PRIMARY KEY (`user_ID`),
  KEY `getPosisi` (`id_posisi`),
  KEY `getDepartemen` (`id_departemen`),
  KEY `getOpmawa` (`id_opmawa`),
  KEY `getProdi` (`id_prodi`),
  CONSTRAINT `getOpmawa` FOREIGN KEY (`id_opmawa`) REFERENCES `opmawa_tbl` (`opmawa_ID`) ON UPDATE CASCADE,
  CONSTRAINT `getProdi` FOREIGN KEY (`id_prodi`) REFERENCES `prodi_tbl` (`prodi_ID`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (1, 'Maulana Rahman Nur', '1', '1', 6, 1, 1, 8, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (7, 'M Rahman N', '2', '2', 2, 2, 1, 1, 2018, 2);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (28, 'Saulia Karina', '3', '3', 6, 1, 1, 4, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (29, 'legisatif 2', '123', '123', 6, 6, 1, 4, 2018, 2);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (30, 'legislatif 3', '333', '333', 6, 8, 1, 6, 2018, 2);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (31, 'dosen', '99', '99', 6, 1, 1, 1, 1, 0);


