#
# TABLE STRUCTURE FOR: berkas_tbl
#

DROP TABLE IF EXISTS `berkas_tbl`;

CREATE TABLE `berkas_tbl` (
  `berkas_ID` int(11) NOT NULL AUTO_INCREMENT,
  `berkas_jenis` varchar(15) DEFAULT NULL,
  `berkas_nama` varchar(50) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_proker` int(11) DEFAULT NULL,
  `berkas_tanggal` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `berkas_lembaga` int(11) NOT NULL,
  `id_opmawa` int(11) NOT NULL,
  PRIMARY KEY (`berkas_ID`),
  KEY `uploadOleh` (`id_user`),
  KEY `berkasProker` (`id_proker`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `berkas_tbl` (`berkas_ID`, `berkas_jenis`, `berkas_nama`, `id_user`, `id_proker`, `berkas_tanggal`, `berkas_lembaga`, `id_opmawa`) VALUES (1, 'lpj', 'LPJ_BEM_FMIPA_TAHUN_2018.pdf', 45, 0, '2020-01-06 15:39:56', 1, 1);
INSERT INTO `berkas_tbl` (`berkas_ID`, `berkas_jenis`, `berkas_nama`, `id_user`, `id_proker`, `berkas_tanggal`, `berkas_lembaga`, `id_opmawa`) VALUES (2, 'lpj', 'BISMILLAH_LPJ_AKHIR_KABINET_PROAKTIF_2018.pdf', 45, 0, '2020-01-13 22:57:49', 1, 2);
INSERT INTO `berkas_tbl` (`berkas_ID`, `berkas_jenis`, `berkas_nama`, `id_user`, `id_proker`, `berkas_tanggal`, `berkas_lembaga`, `id_opmawa`) VALUES (4, 'umum', '17__LAMPIRAN_DOKUMENTASI.docx', 45, 78, '2020-01-26 21:02:02', 1, 2);


#
# TABLE STRUCTURE FOR: departemen_tbl
#

DROP TABLE IF EXISTS `departemen_tbl`;

CREATE TABLE `departemen_tbl` (
  `departemen_ID` int(11) NOT NULL AUTO_INCREMENT,
  `departemen_nama` varchar(50) NOT NULL,
  `id_opmawa` int(11) NOT NULL,
  PRIMARY KEY (`departemen_ID`),
  KEY `id_opmawa` (`id_opmawa`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

INSERT INTO `departemen_tbl` (`departemen_ID`, `departemen_nama`, `id_opmawa`) VALUES (1, 'Badan Pengurus Harian', 1);
INSERT INTO `departemen_tbl` (`departemen_ID`, `departemen_nama`, `id_opmawa`) VALUES (12, 'Advokasi', 1);
INSERT INTO `departemen_tbl` (`departemen_ID`, `departemen_nama`, `id_opmawa`) VALUES (13, 'Ekonomi kreatif', 1);
INSERT INTO `departemen_tbl` (`departemen_ID`, `departemen_nama`, `id_opmawa`) VALUES (14, 'Informasi, komunikasi, dan teknologi', 1);
INSERT INTO `departemen_tbl` (`departemen_ID`, `departemen_nama`, `id_opmawa`) VALUES (15, 'Kaderisasi', 1);
INSERT INTO `departemen_tbl` (`departemen_ID`, `departemen_nama`, `id_opmawa`) VALUES (16, 'Pendidikan dan penelitian', 1);
INSERT INTO `departemen_tbl` (`departemen_ID`, `departemen_nama`, `id_opmawa`) VALUES (17, 'Sosial dan politik', 1);
INSERT INTO `departemen_tbl` (`departemen_ID`, `departemen_nama`, `id_opmawa`) VALUES (18, 'Tank MIPA', 1);
INSERT INTO `departemen_tbl` (`departemen_ID`, `departemen_nama`, `id_opmawa`) VALUES (19, 'Science club', 1);
INSERT INTO `departemen_tbl` (`departemen_ID`, `departemen_nama`, `id_opmawa`) VALUES (20, 'Desa binaan', 1);
INSERT INTO `departemen_tbl` (`departemen_ID`, `departemen_nama`, `id_opmawa`) VALUES (21, 'Forum perempuan', 1);
INSERT INTO `departemen_tbl` (`departemen_ID`, `departemen_nama`, `id_opmawa`) VALUES (22, 'Badan Pengurus Harian', 2);
INSERT INTO `departemen_tbl` (`departemen_ID`, `departemen_nama`, `id_opmawa`) VALUES (24, 'Badan Pengurus Harian', 4);
INSERT INTO `departemen_tbl` (`departemen_ID`, `departemen_nama`, `id_opmawa`) VALUES (25, 'Advokasi dan Keolahragaan', 2);
INSERT INTO `departemen_tbl` (`departemen_ID`, `departemen_nama`, `id_opmawa`) VALUES (26, 'Kaderisasi', 2);
INSERT INTO `departemen_tbl` (`departemen_ID`, `departemen_nama`, `id_opmawa`) VALUES (27, 'Informasi dan Teknologi Kreatif', 2);
INSERT INTO `departemen_tbl` (`departemen_ID`, `departemen_nama`, `id_opmawa`) VALUES (28, 'Computer Science Islamic Centre', 2);


#
# TABLE STRUCTURE FOR: dosen_tbl
#

DROP TABLE IF EXISTS `dosen_tbl`;

CREATE TABLE `dosen_tbl` (
  `dosen_ID` int(11) NOT NULL AUTO_INCREMENT,
  `dosen_nik` int(20) NOT NULL,
  `dosen_nama` varchar(50) NOT NULL,
  `dosen_password` varchar(25) NOT NULL,
  `id_prodi` int(11) NOT NULL,
  PRIMARY KEY (`dosen_ID`),
  KEY `dosen_prodi` (`id_prodi`),
  CONSTRAINT `dosen_prodi` FOREIGN KEY (`id_prodi`) REFERENCES `prodi_tbl` (`prodi_ID`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=latin1;

INSERT INTO `dosen_tbl` (`dosen_ID`, `dosen_nik`, `dosen_nama`, `dosen_password`, `id_prodi`) VALUES (89, 1, 'Bu far', '3', 6);


#
# TABLE STRUCTURE FOR: evaluasirapat_tbl
#

DROP TABLE IF EXISTS `evaluasirapat_tbl`;

CREATE TABLE `evaluasirapat_tbl` (
  `evaluasiRapat_ID` int(11) NOT NULL AUTO_INCREMENT,
  `id_rapat` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `evaluasiRapat_isi` text NOT NULL,
  PRIMARY KEY (`evaluasiRapat_ID`),
  KEY `evaluasiRapat-rapat` (`id_rapat`),
  KEY `evaluasiRapat-user` (`id_user`),
  CONSTRAINT `evaluasiRapat-rapat` FOREIGN KEY (`id_rapat`) REFERENCES `rapat_tbl` (`rapat_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `evaluasiRapat-user` FOREIGN KEY (`id_user`) REFERENCES `user_tbl` (`user_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: opmawa_tbl
#

DROP TABLE IF EXISTS `opmawa_tbl`;

CREATE TABLE `opmawa_tbl` (
  `opmawa_ID` int(11) NOT NULL AUTO_INCREMENT,
  `opmawa_kabinet` varchar(25) NOT NULL,
  `id_user` int(11) NOT NULL,
  `opmawa_tahun` int(5) NOT NULL,
  `opmawa_level` int(11) DEFAULT NULL,
  PRIMARY KEY (`opmawa_ID`),
  KEY `getKetuaNama` (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `opmawa_tbl` (`opmawa_ID`, `opmawa_kabinet`, `id_user`, `opmawa_tahun`, `opmawa_level`) VALUES (1, 'Air Kelapa', 3, 2018, 0);
INSERT INTO `opmawa_tbl` (`opmawa_ID`, `opmawa_kabinet`, `id_user`, `opmawa_tahun`, `opmawa_level`) VALUES (2, 'Proaktif', 92, 2018, 6);


#
# TABLE STRUCTURE FOR: pemasukan_tbl
#

DROP TABLE IF EXISTS `pemasukan_tbl`;

CREATE TABLE `pemasukan_tbl` (
  `pemasukan_ID` int(11) NOT NULL AUTO_INCREMENT,
  `pemasukan_nominal` varchar(15) NOT NULL,
  `pemasukan_deskripsi` varchar(60) NOT NULL,
  `pemasukan_tanggal` date NOT NULL,
  `pemasukan_file` varchar(25) DEFAULT NULL,
  `id_proker` int(5) NOT NULL,
  `pemasukan_lembaga` int(3) NOT NULL,
  `id_opmawa` int(11) NOT NULL,
  PRIMARY KEY (`pemasukan_ID`),
  KEY `OpmawaIDpemasukan` (`id_opmawa`),
  CONSTRAINT `OpmawaIDpemasukan` FOREIGN KEY (`id_opmawa`) REFERENCES `opmawa_tbl` (`opmawa_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;

INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (1, '3052800', 'Saldo kas BEM FMIPA bulan Januari 2018', '2018-01-01', NULL, 0, 1, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (2, '26700', 'Infaq sekret', '2018-02-02', NULL, 0, 1, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (3, '16000', 'Infaq BPH', '2018-02-09', NULL, 0, 1, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (4, '20000', 'Infaq peminjaman inventaris', '2018-02-23', NULL, 0, 1, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (5, '31500', 'Infaq BPH', '2018-03-20', NULL, 0, 1, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (6, '1880000', 'Uang PKMF dari rektorat', '2018-05-10', NULL, 0, 1, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (7, '350000', 'Uang DIVA dari dekanat', '2018-05-21', NULL, 0, 1, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (10, '30000', 'Infaq BPH', '2018-06-01', NULL, 0, 1, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (11, '350000', 'Uang DIVA dari dekanat tahap 2', '2018-06-21', NULL, 0, 1, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (12, '2000000', 'Feskes (dekanat)', '2018-07-06', NULL, 0, 1, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (13, '802000', 'Turunan uang KMB', '2018-08-10', NULL, 0, 1, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (14, '1000000', 'Feskes (dekanat)', '2018-09-07', NULL, 0, 1, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (15, '1050000', 'Feskes (dekanat)', '2018-10-18', NULL, 0, 1, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (16, '150000', 'Kembalian rektor cup', '2018-10-22', NULL, 0, 1, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (17, '1880000', 'Seminar (rektorat)', '2018-11-16', NULL, 0, 1, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (18, '5000000', 'FEMI', '2018-11-23', NULL, 0, 1, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (19, '4935000', 'LKTIN', '2018-11-23', NULL, 0, 1, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (20, '2750000', 'M3D', '2018-11-23', NULL, 0, 1, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (21, '2085000', 'PKKMB (surplus)', '2018-11-26', NULL, 0, 1, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (22, '500500', 'Uang turunan dari BPM periode 2017-2018', '2018-02-23', NULL, 0, 2, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (24, '155000', 'Kas bulan Februari', '2018-02-28', NULL, 0, 2, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (25, '240000', 'Iuran ID card (16 orang)', '2018-02-28', NULL, 0, 2, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (26, '70000', 'Kas bulan Maret', '2018-03-31', NULL, 0, 2, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (27, '200000', 'Kas bulan April', '2018-04-30', NULL, 0, 2, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (28, '140000', 'Kas bulan Mei', '2018-05-31', NULL, 0, 2, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (29, '890000', 'Iuran PDL anggota BPM bulan Juni', '2018-06-28', NULL, 0, 2, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (30, '400000', 'Iuran PDL anggota BPM bulan Juli', '2018-07-31', NULL, 0, 2, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (31, '675000', 'Iuran PDL anggota BPM bulan Agustus', '2018-08-31', NULL, 0, 2, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (32, '145000', 'Surplus PLMF diterima dari Bella', '2018-07-06', NULL, 0, 2, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (33, '54500', 'Surplus kaleg diterima dari Bella', '2018-10-08', NULL, 0, 2, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (34, '300000', 'Surplus PLMF diterima dari Bella', '2018-12-07', NULL, 0, 2, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (35, '410000', 'Kas Juli - Desember', '2018-12-31', NULL, 0, 2, 1);
INSERT INTO `pemasukan_tbl` (`pemasukan_ID`, `pemasukan_nominal`, `pemasukan_deskripsi`, `pemasukan_tanggal`, `pemasukan_file`, `id_proker`, `pemasukan_lembaga`, `id_opmawa`) VALUES (36, '10000', 'Pemasukan', '2020-01-26', NULL, 77, 1, 2);


#
# TABLE STRUCTURE FOR: pengeluaran_tbl
#

DROP TABLE IF EXISTS `pengeluaran_tbl`;

CREATE TABLE `pengeluaran_tbl` (
  `pengeluaran_ID` int(11) NOT NULL AUTO_INCREMENT,
  `pengeluaran_nominal` varchar(15) NOT NULL,
  `pengeluaran_deskripsi` varchar(60) NOT NULL,
  `pengeluaran_tanggal` date NOT NULL,
  `pengeluaran_file` varchar(25) DEFAULT NULL,
  `id_proker` int(5) NOT NULL,
  `pengeluaran_lembaga` int(3) NOT NULL,
  `id_opmawa` int(11) NOT NULL,
  PRIMARY KEY (`pengeluaran_ID`),
  KEY `OpmawaID` (`id_opmawa`),
  CONSTRAINT `OpmawaID` FOREIGN KEY (`id_opmawa`) REFERENCES `opmawa_tbl` (`opmawa_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=latin1;

INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (1, '180000', 'Modal untuk Ekre', '2018-02-07', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (2, '130000', 'Fiksasi', '2018-02-09', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (3, '70000', 'Uang kebersihan pra-RKB', '2018-02-23', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (4, '72000', 'Materai untuk RKB', '2018-02-27', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (5, '85000', 'Konsumsi RKB', '2018-02-27', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (6, '30000', 'Uang kebersihan RKB', '2018-02-27', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (7, '27000', 'Print TOR', '2018-02-28', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (8, '68000', 'Print TOR revisi', '2018-03-05', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (9, '67500', 'Diklit zone', '2018-03-14', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (10, '200000', 'KURUS I', '2018-03-23', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (11, '100000', 'KPS', '2018-03-26', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (12, '300100', 'Pembayaran web', '2018-03-19', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (13, '90000', 'Banner penyambutan maba', '2018-04-01', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (14, '67500', 'Banner diklit zone', '2018-04-19', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (15, '200000', 'KURUS II', '2018-04-20', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (16, '200000', 'Kajian pendidikan', '2018-04-23', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (17, '1000000', 'PKMF 2018', '2018-05-11', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (18, '38000', 'Outbond PKMF', '2018-05-12', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (20, '372000', 'DIVA', '2018-04-23', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (21, '1000000', 'Feskes', '2018-07-04', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (22, '137000', 'DIVA (ganti bon)', '2018-07-06', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (23, '225000', 'Beli cadridge', '2018-07-10', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (24, '45000', 'Banner ', '2018-07-19', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (25, '225000', 'Cadridge warna + tinta', '2018-07-19', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (26, '160000', 'X banner', '2018-07-16', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (27, '1500000', 'Feskes', '2018-07-06', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (28, '96000', 'Jendela MIPA', '2018-07-20', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (29, '90000', 'Banner penyambutan maba', '2018-07-18', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (30, '100000', 'Uang kebersihan sidang pleno', '2018-08-11', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (31, '115000', 'DIVA (ganti bon)', '2018-08-11', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (32, '75000', 'Pembatas buku', '2018-08-16', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (33, '200000', 'BUMI', '2018-09-06', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (34, '1000000', 'Rektor cup', '2018-09-07', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (35, '100000', 'KURUS', '2018-09-28', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (36, '122000', 'Booklet PKKMB (untuk SPJ) ', '2018-10-19', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (37, '260000', 'PKKMB (ganti bon)', '2018-10-19', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (38, '45000', 'Beli HVS (1 rim)', '2018-10-27', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (39, '1500000', 'FEMI', '2018-10-27', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (40, '300000', 'M3D', '2018-11-21', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (41, '2000000', 'Seminar entrepreneur', '2018-12-01', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (42, '2500000', 'FEMI (ganti bon)', '2018-12-05', NULL, 0, 1, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (43, '20000', 'Uang kebersihan RKB GDS Lt 10', '2018-02-27', NULL, 0, 2, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (44, '22000', 'Konsumsi RKB', '2018-02-27', NULL, 0, 2, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (45, '13500', 'Eco notes untuk pembuatan mading BPM (diberikan kepada Rosit', '2018-03-06', NULL, 0, 2, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (46, '46500', 'ATK untuk pembuatan mading BPM (diberikan kepada Dikny)', '2018-03-07', NULL, 0, 2, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (47, '250000', 'Pembayaran ID Card (diberikan kepada Dessy)', '2018-04-05', NULL, 0, 2, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (48, '45000', 'Bingkisan sosialisasi PO (diberikan kepada Nur Devi Vani)', '2018-04-27', NULL, 0, 2, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (49, '25000', 'Tambahan pembayaran ID Card (diberikan kepada Dessy)', '2018-05-30', NULL, 0, 2, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (50, '1000000', 'Pembayaran uang muka PDL diberikan kepada Rahid', '2018-06-28', NULL, 0, 2, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (51, '100000', 'Concord dan nametag TIPE diberikan kepada Dessy', '2018-06-28', NULL, 0, 2, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (52, '100000', 'Merchant welcoming maba diberikan kepada Dessy', '2018-07-15', NULL, 0, 2, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (53, '145000', 'Konsumsi pleno', '2018-08-31', NULL, 0, 2, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (54, '195000', 'Pemakaian untuk kebersihan pleno', '2018-08-31', NULL, 0, 2, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (55, '1033000', 'Pelunasan PDL', '2018-09-02', NULL, 0, 2, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (56, '50000', 'Bendera BPM diberikan kepada Agung', '2018-07-06', NULL, 0, 2, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (57, '20000', 'Proposal OH diberikan kepada Dessy', '2018-09-28', NULL, 0, 2, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (58, '75000', 'Cap BPM (Dessy)', '2018-10-19', NULL, 0, 2, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (59, '80000', 'Cap KPU (Agung)', '2018-10-21', NULL, 0, 2, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (60, '100000', 'PKMF', '2018-11-11', NULL, 0, 2, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (61, '150000', 'KPU', '2018-11-19', NULL, 0, 2, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (62, '450000', 'Pembayaran ruangan sidang umum', '2018-12-31', NULL, 0, 2, 1);
INSERT INTO `pengeluaran_tbl` (`pengeluaran_ID`, `pengeluaran_nominal`, `pengeluaran_deskripsi`, `pengeluaran_tanggal`, `pengeluaran_file`, `id_proker`, `pengeluaran_lembaga`, `id_opmawa`) VALUES (63, '2000', 'Amal', '2020-01-27', NULL, 77, 1, 2);


#
# TABLE STRUCTURE FOR: posisi_tbl
#

DROP TABLE IF EXISTS `posisi_tbl`;

CREATE TABLE `posisi_tbl` (
  `posisi_ID` int(11) NOT NULL AUTO_INCREMENT,
  `posisi_nama` varchar(25) NOT NULL,
  `posisi_lembaga` int(1) NOT NULL,
  PRIMARY KEY (`posisi_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

INSERT INTO `posisi_tbl` (`posisi_ID`, `posisi_nama`, `posisi_lembaga`) VALUES (1, 'Ketua umum', 1);
INSERT INTO `posisi_tbl` (`posisi_ID`, `posisi_nama`, `posisi_lembaga`) VALUES (2, 'Ketua umum', 2);
INSERT INTO `posisi_tbl` (`posisi_ID`, `posisi_nama`, `posisi_lembaga`) VALUES (3, 'Ketua departemen / biro', 1);
INSERT INTO `posisi_tbl` (`posisi_ID`, `posisi_nama`, `posisi_lembaga`) VALUES (4, 'Anggota departemen / biro', 1);
INSERT INTO `posisi_tbl` (`posisi_ID`, `posisi_nama`, `posisi_lembaga`) VALUES (5, 'Ketua underbow', 1);
INSERT INTO `posisi_tbl` (`posisi_ID`, `posisi_nama`, `posisi_lembaga`) VALUES (6, 'Ketua komisi', 2);
INSERT INTO `posisi_tbl` (`posisi_ID`, `posisi_nama`, `posisi_lembaga`) VALUES (7, 'Anggota komisi', 2);
INSERT INTO `posisi_tbl` (`posisi_ID`, `posisi_nama`, `posisi_lembaga`) VALUES (8, 'Ketua fraksi', 2);
INSERT INTO `posisi_tbl` (`posisi_ID`, `posisi_nama`, `posisi_lembaga`) VALUES (9, 'Kepala BURT', 2);
INSERT INTO `posisi_tbl` (`posisi_ID`, `posisi_nama`, `posisi_lembaga`) VALUES (10, 'Bendahara', 2);
INSERT INTO `posisi_tbl` (`posisi_ID`, `posisi_nama`, `posisi_lembaga`) VALUES (11, 'Sekretaris', 2);
INSERT INTO `posisi_tbl` (`posisi_ID`, `posisi_nama`, `posisi_lembaga`) VALUES (12, 'Humas', 2);
INSERT INTO `posisi_tbl` (`posisi_ID`, `posisi_nama`, `posisi_lembaga`) VALUES (13, 'BALEG', 2);
INSERT INTO `posisi_tbl` (`posisi_ID`, `posisi_nama`, `posisi_lembaga`) VALUES (14, 'BADAS', 2);
INSERT INTO `posisi_tbl` (`posisi_ID`, `posisi_nama`, `posisi_lembaga`) VALUES (15, 'BAKAR', 2);
INSERT INTO `posisi_tbl` (`posisi_ID`, `posisi_nama`, `posisi_lembaga`) VALUES (16, 'Sekretaris umum', 1);
INSERT INTO `posisi_tbl` (`posisi_ID`, `posisi_nama`, `posisi_lembaga`) VALUES (17, 'Bendahara umum', 1);
INSERT INTO `posisi_tbl` (`posisi_ID`, `posisi_nama`, `posisi_lembaga`) VALUES (18, 'Sekretaris departemen / b', 1);
INSERT INTO `posisi_tbl` (`posisi_ID`, `posisi_nama`, `posisi_lembaga`) VALUES (19, 'Bendahara departemen / bi', 1);


#
# TABLE STRUCTURE FOR: prodi_tbl
#

DROP TABLE IF EXISTS `prodi_tbl`;

CREATE TABLE `prodi_tbl` (
  `prodi_ID` int(11) NOT NULL AUTO_INCREMENT,
  `prodi_nama` varchar(50) NOT NULL,
  PRIMARY KEY (`prodi_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

INSERT INTO `prodi_tbl` (`prodi_ID`, `prodi_nama`) VALUES (1, 'Pendidikan Matematika');
INSERT INTO `prodi_tbl` (`prodi_ID`, `prodi_nama`) VALUES (5, 'Matematika');
INSERT INTO `prodi_tbl` (`prodi_ID`, `prodi_nama`) VALUES (6, 'Ilmu Komputer');
INSERT INTO `prodi_tbl` (`prodi_ID`, `prodi_nama`) VALUES (7, 'Statistika');
INSERT INTO `prodi_tbl` (`prodi_ID`, `prodi_nama`) VALUES (8, 'Fisika');
INSERT INTO `prodi_tbl` (`prodi_ID`, `prodi_nama`) VALUES (9, 'Pendidikan Fisika');
INSERT INTO `prodi_tbl` (`prodi_ID`, `prodi_nama`) VALUES (10, 'Biologi');
INSERT INTO `prodi_tbl` (`prodi_ID`, `prodi_nama`) VALUES (11, 'Kimia');
INSERT INTO `prodi_tbl` (`prodi_ID`, `prodi_nama`) VALUES (12, 'Pendidikan Biologi');
INSERT INTO `prodi_tbl` (`prodi_ID`, `prodi_nama`) VALUES (13, 'Pendidikan Kimia');


#
# TABLE STRUCTURE FOR: proker_tbl
#

DROP TABLE IF EXISTS `proker_tbl`;

CREATE TABLE `proker_tbl` (
  `proker_ID` int(11) NOT NULL AUTO_INCREMENT,
  `proker_nama` varchar(100) NOT NULL,
  `proker_deskripsi` text NOT NULL,
  `proker_tanggal` date DEFAULT NULL,
  `proker_jenis` varchar(10) DEFAULT NULL,
  `proker_lembaga` int(2) NOT NULL,
  `proker_tahun` int(5) NOT NULL,
  `proker_nilai` varchar(5) DEFAULT NULL,
  `proker_output` text,
  `id_opmawa` int(11) DEFAULT NULL,
  PRIMARY KEY (`proker_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=latin1;

INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (12, 'Pelatihan Kepemimpinan Mahasiswa FMIPA ', 'Sebagai salah satu program  untuk menghasilkan mahasiswa FMIPA yang kritis, peka terhadap masalah di lingkungan masyarakat, serta memiliki jiwa sosial di masyarakat nantinya terutama di lingkungan FMIPA', '2018-04-02', 'event', 1, 2018, NULL, 'Sebagai salah satu program  untuk menghasilkan mahasiswa FMIPA yang kritis, peka terhadap masalah di lingkungan masyarakat, serta memiliki jiwa sosial di masyarakat nantinya terutama di lingkungan FMIPA', 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (13, 'Family day', 'Kegiatan Famday BEM FMIPA diadakan sebagai bentuk penjagaan, yang merupakan fungsi dari departemen kaderisasi, selain itu sebagai bentuk Quality time bagi kader BEM FMIPA', '0000-00-00', 'non_event', 1, 2018, NULL, 'Sebagai salah satu program  untuk menghasilkan mahasiswa FMIPA yang kritis, peka terhadap masalah di lingkungan masyarakat, serta memiliki jiwa sosial di masyarakat nantinya terutama di lingkungan FMIPA', 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (14, 'BE-MINION, FISI, dan DBD ', 'BEMF MIPA notifications, FMIPA menginspirasi, dan Dekat Bersama Mereka', '0000-00-00', 'non_event', 1, 2018, NULL, 'Untuk BE-MINION dilaksanakan untuk mengabarkan, kabar setiap anggota BEM FMIPA baik ulang tahun, kabar duka, ataupun musibah yang akan selalu update tiap harinya. Untuk FISI dilaksanakan tiap pekan dengan memberikan motivasi ke setiap kader , melalui media sosial Whats App yang di laksanakan oleh delegasi di tiap departemen. Dan untuk DBD dilaksanakan 2 pekan sekali dengan narasumber yang berbeda-beda', 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (15, 'Sahabat kaderisasi', 'Perlu adanya penjagaan dari kaderisasi ke tiap departemen BEM FMIPA dan juga ke tiap Prodi. Sebagai sarana mempererat tali silaturahmi dan juga sebagai bentuk monitoring kondisi di tiap departemen dan BEM Prodi', '0000-00-00', 'non_event', 1, 2018, NULL, NULL, 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (16, 'SOL (School of Leadership)', 'Diperlukannya alur pengkaderan untuk mempersiapkan kader yang akan meneruskan tonggak perjuangan di BEM FMIPA. Dalam bergorganisasi penting bagi kita untuk meningkatkan kualitas kepemimpinan kita, maka hadirlah SOL untuk mengembangkan jiwa kepemimpin', '0000-00-00', 'non_event', 1, 2018, NULL, 'Diperlukannya alur pengkaderan untuk mempersiapkan kader yang akan meneruskan tonggak perjuangan di BEM FMIPA. Dalam bergorganisasi penting bagi kita untuk meningkatkan kualitas kepemimpinan kita, maka hadirlah SOL untuk mengembangkan jiwa kepemimpinan terkhusus untuk anggota BEM se MIPA', 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (17, 'Pengenalan Kehidupan Kampus Mahasiswa Baru FMIPA', 'PKKMB FMIPA merupakan suatu agenda yang dilatarbelakangi banyaknya mahasiswa baru yang masih susah beradaptasi dengan dunia kampus, terutama dalam hal keakademikan dan organisasi yang berada di dalam kampus', '2018-01-01', 'event', 1, 2018, NULL, NULL, 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (18, 'Diklit Zone', 'Diklit Zone merupakan program kerja yang sudah dilaksanakan di tahun sebelumnya. Program kerja ini merupakan bagian dari info-info mengenai keilmiahan seperti info lomba, info prestasi, lelang judul, dan info terkini dari hasil diskusi. Semua sub-sub proker ini memiliki perbedaan waktu pelaksanaan. Info lomba dilaksanakan 2 minggu sekali, pada 6 bulan pertama info lomba disebar melalui grup namun berdasarkan evaluasi dan diskusi, info lomba dibuatkan grup khusus. Info prestasi berisifat tentatif, dibuat sesuai dengan kondisi.  Lelang judul dipertengahan tahun, dan diskusi ilmiah diadakan sebulan sekali. Dari semua hal ini yang berjalan hanya info prestasi, info lomba dan diskusi ilmiah sedangkan lelang judul belum terlaksana', '0000-00-00', 'non_event', 1, 2018, NULL, 'Diklit Zone merupakan program kerja yang sudah dilaksanakan di tahun sebelumnya. Program kerja ini merupakan bagian dari info-info mengenai keilmiahan seperti info lomba, info prestasi, lelang judul, dan info terkini dari hasil diskusi. Semua sub-sub proker ini memiliki perbedaan waktu pelaksanaan. Info lomba dilaksanakan 2 minggu sekali, pada 6 bulan pertama info lomba disebar melalui grup namun berdasarkan evaluasi dan diskusi, info lomba dibuatkan grup khusus. Info prestasi berisifat tentatif, dibuat sesuai dengan kondisi.  Lelang judul dipertengahan tahun, dan diskusi ilmiah diadakan sebulan sekali. Dari semua hal ini yang berjalan hanya info prestasi, info lomba dan diskusi ilmiah sedangkan lelang judul belum terlaksana. ', 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (19, 'kajian Pendidikan', 'Kajian Pendidikan merupakan kajian tahunan yang biasanya diadakan untuk menyambut event-event kependidikan, seperti Hardiknas dan Hari Guru. Pada Hardiknas kemarin, kajian pendidikan ini dapat terlaksana dengan dua kali pertemuan yaitu online dan off', '0000-00-00', 'non_event', 1, 2018, NULL, 'Kajian Pendidikan merupakan kajian tahunan yang biasanya diadakan untuk menyambut event-event kependidikan, seperti Hardiknas dan Hari Guru. Pada Hardiknas kemarin, kajian pendidikan ini dapat terlaksana dengan dua kali pertemuan yaitu online dan offline. Peserta yang datang cukup banyak tetapi semua kegiatan dilaksanakannya secara selalu mepet. Di Kajian Pendidikan ini, seharusnya mendapatkan dana rektorat tetapi proposal yang diajukan terlalu lama dibuat sehingga tidak dapat dicairkan. Kajian pendidikan berikutnya dilakukan sebanyak tiga kali berturut-turut dengan tema pengembangan softskill mahasiswa dimana pelaksanaannya dibantu oleh pihak dekanat. Peserta yang hadir tidak begitu banyak karena dilaksanakan siang hari pada jam kuliah namun ada yang diisi oleh prodi biologi sebagai kuliah umum wajib.', 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (20, 'Festival MIPA UNJ 2018', 'Festival MIPA merupakan program kerja Depatemen Pendidikan dan Penelitian Badan Eksekutif Mahasiswa Fakultas Matematika dan Ilmu Pengetahuan Alam Universitas Negeri Jakarta 2018. Kegiatan ini terdiri dari Pelangi Matematika 25, Pekan Ilmiah Fisika, T', '2018-01-01', 'event', 1, 2018, NULL, 'Festival MIPA merupakan program kerja Depatemen Pendidikan dan Penelitian Badan Eksekutif Mahasiswa Fakultas Matematika dan Ilmu Pengetahuan Alam Universitas Negeri Jakarta 2018. Kegiatan ini terdiri dari Pelangi Matematika 25, Pekan Ilmiah Fisika, Temu Kimia XXII, dan Biology Learning Festival. Kegiatan ini meliputi Olimpiade IPA Terpadu, Olimpiade Matematika (SD/MI/Sederajat, SMP/MTs/Sederajat, SMA/MA/SMK/Sederajat), Galileo dan Eistein Competition (SMA/MA/SMK/Sederajat), Pesona Kimia (SMA/MA/SMK/Sederajat), dan Olimpiade Biologi (SMA/MA/SMK/Sederajat). Selain itu acara tahun ini ditambah dengan Lomba Karya Tulis Nasional Festival MIPA 2018, dan Seminar. Olimpiade ini diadakan untuk seluruh Siswa/i di Indonesia. Dengan izin Allah, proker ini dapat berjalan dengan lancar dan tidak mengalami defisit.', 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (21, 'Orientasi Science Club (OSC)', 'Kegiatan ini terdiri dari dua bagian yaitu Pra OSC dan OSC. Pra OSC dilaksanakan pada hari Sabtu, 24 Maret 2018 bertempat di Gedung Dewi Sartika Lt. 10, Kampus A UNJ. Untuk hari-H OSC berlangsung pada Sabtu-Minggu, 78 April 2018 di PP IPTEK TMII. Ada', '2018-03-24', 'event', 1, 2018, NULL, 'Kegiatan ini terdiri dari dua bagian yaitu Pra OSC dan OSC. Pra OSC dilaksanakan pada hari Sabtu, 24 Maret 2018 bertempat di Gedung Dewi Sartika Lt. 10, Kampus A UNJ. Untuk hari-H OSC berlangsung pada Sabtu-Minggu, 78 April 2018 di PP IPTEK TMII. Adapun kegiatan ini bertujuan untuk meningkatkan budaya ilmiah dikalangan mahasiswa FMIPA, meningkatkan kemampuan menulis dikalangan mahasiswa FMIPA, memperkenalkan seluk beluk penelitian kepada mahasiswa FMIPA, menumbuhkan daya tarik \r\n\r\n \r\nmahasiswa FMIPA dalam bidang penelitian, meningkatkan motivasi berprestasi yang didapat dari narasumber yang dihadirkan dalam acara OSC dan melakukan pengkaderan calon anggota Science Club. Pelaksanaan OSC banyak mengalami kendala. Kesibukkan panitia ditempat lain menyebabkan beberapa tugas sie back up dengan panitia lain dan kegiatan OSC ini kurang maksimal dilihat dari sedikitnya peserta yang ikut sampai OSC Perlu komunikasi yang intensif antar panitia dengan angggota diklit BEMF agar saling memberikan motivasi dan mengingatkan dalam kebaikan. \r\n ', 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (22, 'Reform', '-', '2018-12-03', 'event', 1, 2018, NULL, NULL, 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (23, 'Festival kesehatan', 'Festival Kesehatan 2018 di komandoi oleh Muhammad Irfan Ananda.Program ini terlaksana pada tanggal 7 juni 2018 melayani berbagai pelayanan kesehatan yang  berkerjasama dengan Ikatan Dokter Indonesia (IDI). Dengan jumlah peserta sebanyak 100 peserta khitanan masal, pengobatan umum, bedah minor, dan periksa gigi. Pada tahun ini festival kesehatan di laksanakan lebih awal dari tahun sebelumnya baru terselenggara pada bulan September', '2018-06-07', 'event', 1, 2018, NULL, 'Festival Kesehatan 2018 di komandoi oleh Muhammad Irfan Ananda.Program ini terlaksana pada tanggal 7 juni 2018 melayani berbagai pelayanan kesehatan yang berkerjasama dengan Ikatan Dokter Indonesia (IDI). Dengan jumlah peserta sebanyak 100 peserta khitanan masal, pengobatan umum, bedah minor, dan periksa gigi. Pada tahun ini festival kesehatan di laksanakan lebih awal dari tahun sebelumnya baru terselenggara pada bulan September', 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (24, 'Lemari baca anak MIPA', 'Dalam pelaksanaannya, Lemari baca ini kurang maksimal dikarenakan perijinan penempatan lemari yang terkendala ijin dari pihak dekanat. Sehingga buku-buku yang sudah ada hanya diletakkan di secretariat BEM FMIPA lantai 4 GHA', '2018-06-07', 'non_event', 1, 2018, NULL, 'Dalam pelaksanaannya, Lemari baca ini kurang maksimal dikarenakan perijinan penempatan lemari yang terkendala ijin dari pihak dekanat. Sehingga buku-buku yang sudah ada hanya diletakkan di secretariat BEM FMIPA lantai 4 GHA', 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (25, 'Ketuk pintu sospol', 'Dalam rangka silaturahmi dan haering antara underbow dengan Departemen Sospol di laksanakan agenda KPS. Program ini berjalan satu kali selama priode kepengurusan pada tanggal 25 maret bertempat di rumah Irfan.  Dalam agenda ini di hadiri oleh anggota Departemen Sospol, desa binaan , TAnK MIPA, Forum Perempuan FMIPA', '2018-06-07', 'non_event', 1, 2018, NULL, 'Dalam rangka silaturahmi dan haering antara underbow dengan Departemen Sospol di laksanakan agenda KPS. Program ini berjalan satu kali selama priode kepengurusan pada tanggal 25 maret bertempat di rumah Irfan. Dalam agenda ini di hadiri oleh anggota Departemen Sospol, desa binaan , TAnK MIPA, Forum Perempuan FMIPA', 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (26, 'Aksi sospol', 'Dalam berapa momentum kami melakukan aksi turun ke jalan diantaranya :Aksi bela rupiah (14 september 2018),  Aksi tugu tani (24 september 2018), Aksi Nasional Jokowi-JK (29 oktober 2018), Aksi Gruduk Kemenristekdikti (13 Desember 2018),dll ', '2018-06-07', 'non_event', 1, 2018, NULL, 'Dalam berapa momentum kami melakukan aksi turun ke jalan diantaranya :Aksi bela rupiah (14 september 2018), Aksi tugu tani (24 september 2018), Aksi Nasional Jokowi-JK (29 oktober 2018), Aksi Gruduk Kemenristekdikti (13 Desember 2018),dll', 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (27, 'FMIPA peduli', 'Dalam rangka tanggap bencana  Departemen Sospol FMIPA beberapa kali melakukan penggalangan donasi untuk korban bencana alam salah satunnya pada saat \r\n\r\n \r\ngemba Lombok dan Tsunami Palu. Bantuan yang di berikan berupa uang tunai dan pakaian layak pakai', '2018-06-07', 'non_event', 1, 2018, NULL, 'Dalam rangka tanggap bencana Departemen Sospol FMIPA beberapa kali melakukan penggalangan donasi untuk korban bencana alam salah satunnya pada saat gemba Lombok dan Tsunami Palu. Bantuan yang di berikan berupa uang tunai dan pakaian layak pakai', 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (28, 'Sidang paripurna', 'Sidang yang diselenggarakan untuk melaksanakan tugas dan wewenang lembaga legislatif. Seperti mengesahkan anggota BPM, pengesahan ketua KPU', '0000-00-00', 'non_event', 2, 2018, NULL, NULL, 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (29, 'Rapat koordinasi I', 'Sidang yang bertujuan untuk membahas dan mengesahkan peraturan internal, struktur, timeline, dan agenda kerja BPM', '0000-00-00', 'non_event', 2, 2018, NULL, NULL, 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (30, 'Rapat koordinasi II', 'Sidang yang bertujuan untuk membuat dan pembahasan awal draft mekanisme pengawasan, mekanisme anggaran, dan mekanisme aspirasi', '0000-00-00', 'non_event', 2, 2018, NULL, NULL, 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (31, 'Pra rapat kerja bersama BEMF', 'Membahas mekanisme pengawasan, mekanismen anggaran, dan mekanisme aspirasi dengan BEMF serta membahas peraturan ketua BEMF dan proker-proker BEMF', '0000-00-00', 'non_event', 2, 2018, NULL, NULL, 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (32, 'Rapat kerja bersama BEMF', 'Mengesahkan mekanisme pengawasan, mekanisme anggaran, mekanisme aspirasi, peraturan ketua BEMF dan proker-proker BEMF', '0000-00-00', 'non_event', 2, 2018, NULL, NULL, 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (33, 'Rapat kerja bersama dekanat', 'Membahas dan mengesahkan program keja BEMF dan agenda kerja BPM beserta anggaranya dengan dekanat FMIPA', '0000-00-00', 'non_event', 2, 2018, NULL, NULL, 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (34, 'Rapat pimpinan', 'Membahas kabar tiap fraksi dan menentukan langkah strategis lainnya', '0000-00-00', 'non_event', 2, 2018, NULL, NULL, 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (35, 'Rapat dengar pendapat komisi', 'Rapat yang dilakukan untuk mengkonfirmasi sesuatu antara komisi pengawas dengan departemen yang diawasi', '0000-00-00', 'non_event', 2, 2018, NULL, NULL, 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (36, 'Sidang pleno', 'Sidang untuk mengevaluasi tengah periode kinerja BEMF dan BPM', '0000-00-00', 'non_event', 2, 2018, NULL, NULL, 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (37, 'Sidang umum BPM FMIPA UNJ', 'Forum tertinggi Opmawa FMIPA yang dilaksanakan akhir periode', '0000-00-00', 'non_event', 2, 2018, NULL, NULL, 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (38, 'SOP administrasi', 'SOP yang mengatur tata administrasi di Opmawa FMIPA', '0000-00-00', 'non_event', 2, 2018, NULL, NULL, 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (39, 'Buletin legislatif', 'Buletin yang berisikan info-info tentang legislatif FMIPA', '0000-00-00', 'non_event', 2, 2018, NULL, NULL, 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (40, 'Identity card', 'Kartu anggota BPM FMIPA', '0000-00-00', 'non_event', 2, 2018, NULL, NULL, 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (41, 'Legislatif news', 'Artikel berita yang membahas tema kelegislatifan', '0000-00-00', 'non_event', 2, 2018, NULL, NULL, 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (42, 'Studi banding legislatif', 'Studi banding ke lembaga legislatif lain', '0000-00-00', 'non_event', 2, 2018, NULL, NULL, 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (43, 'Open house legislatif', 'Penyambutan mahasiswa baru dari lembaga legislatif se-MIPA', '2018-01-01', 'event', 2, 2018, NULL, NULL, 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (44, 'Media sosial legislatif', 'Sosial media BPM FMIPA', '2018-01-01', 'non_event', 2, 2018, NULL, NULL, 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (45, 'DIVA', 'Forum dialog seluruh civitas akademika FMIPA', '2018-01-01', 'event', 2, 2018, NULL, NULL, 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (46, 'Class to class', 'Menjaring aspirasi mahasiswa dengan cara masuk ke kelas-kelas', '0000-00-00', 'non_event', 2, 2018, NULL, NULL, 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (47, 'Hearing', 'BPM FMIPA untuk menjaring aspirasi legislatif prodi dengan cara menemui langsung', '0000-00-00', 'non_event', 2, 2018, NULL, NULL, 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (48, 'Jaring aspirasi', 'Menjaring aspirasi mahasiswa', '0000-00-00', 'non_event', 2, 2018, NULL, NULL, 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (49, 'PLMF', 'Proses kaderisasi anggota legislatif tingkat fakultas', '2018-01-01', 'event', 2, 2018, NULL, NULL, 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (50, 'Family day BPM FMIPA UNJ', 'Proses silaturahim untuk menguatkan ikatan antar anggota BPM', '2018-01-01', 'non_event', 2, 2018, NULL, NULL, 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (51, 'Kajian legislatif', 'Salah satu program kaderisasi dalam hal peningkatan pemahaman kelegislatifan', '2018-01-01', 'event', 2, 2018, NULL, NULL, 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (52, 'Sosialisasi peraturan Opmawa', 'Salah satu program kaderisasi dalam hal peningkatan pemahaman kelegislatifan di bidang legislasi', '2018-01-01', 'event', 2, 2018, NULL, NULL, 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (53, 'Pengawasan proker BEM', 'Mengawasi setiap program kerja BEMF', '2018-01-01', 'non_event', 2, 2018, NULL, NULL, 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (54, 'Komisi pemilihan umum', 'Lembaga independent yang menyelenggarakan pemilu', '2018-01-01', 'non_event', 2, 2018, NULL, NULL, 1);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (55, ' Pundi dan Nadi', 'Nadi merupakan program turunan dari Departemen Advokasi BEM UNJ', '0000-00-00', 'non_event', 1, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (56, 'Computer Science Sport (CSS) ', 'Computer Science Sport adalah suatu perlombaan keolahragaan yang coba mempertemukan tiap kelas/prodi yang ada dengan cabang olahraga diantara lain futsal putra/putri, voli putra, catur putra/putri, tarik tambang putra/putri, basket putra, Estafet dan E-Sport yang telah direncanakan berlangsung pada bulan Mei 2018', '2018-05-02', 'event', 1, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (57, ' Bank Data Mahasiswa (BADAI) ', 'BADAI merupakan proker pengumpulan data mahasiswa', '2018-05-02', 'non_event', 1, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (58, 'Bank Data Kuliah (BADAK) ', 'BADAI merupakan proker pengumpulan data mata kuliah yang di dapat dari soal-soal pada saat ujian ', '2018-05-02', 'non_event', 1, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (59, 'Agen Advor ', 'Agen advor merupakan mahasiswa yang menjadi perwakilan untuk setiap kelas di angkatannya sebagai wadah penyampai informasi dan sebagai wadah penjaring aspirasi', '2018-05-02', 'non_event', 1, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (60, ' I-Lowker Beasiswa Lomba', 'Informasi Lowongan Kerja, beasiswa, dan lomba', '2018-05-02', 'non_event', 1, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (61, ' Apresiasi Wisuda Mahasiswa Ilmu Komputer', 'Pada semester 108 dan 109, Prodi Ilmu Komputer memiliki Mahasiswa yang lulus sebanyak 12 orang, dan seluruh memdapatkan Siluet yang diberikan saat Acara Wisuda yang bertempat di Hall D2 Jiexpo Kemayoran.', '2018-05-02', 'non_event', 1, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (62, 'Fun Fact Sport', 'Proker yang bergerak dalam bidang publikasi yang memberikan info menarik tentang dunia olahraga, Proker ini juga belum terlaksana lantaran masih belum adanya Sosialisasi kepada Masyarakat Ilmu Komputer', '2018-05-02', 'non_event', 1, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (63, 'Family Day', 'Sebuah acara silaturahmi antar pengurus opmawa prodi ilmu komputer', '2018-05-02', 'non_event', 1, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (64, 'PKKMB prodi ilmu komputer', 'PKKMB Prodi Ilmu Komputer merupakan wadah pengkaderan bagi mahasiswa baru yang akan mulai memasuki dunia kampus. PKKMB Prodi Ilmu Komputer ini berlangsung pada tanggal 18 Agustus dan 7 September 2018 yang bertempat di Gedung Hasyim Asjarie. ', '2018-08-17', 'event', 1, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (65, 'Muhasabah Perjuangan', '-', '2018-08-17', 'non_event', 1, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (66, 'Upgrading staff', 'Disatukan dengan Famday I', '2018-08-17', 'non_event', 1, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (67, 'Hati ke Hati', 'Hati ke Hati kami melaksanakan nya secara Online. Hati ke Hati  ini dilaksanakan setiap malam minggu sampai akhir kepengurusan. Berlangsung pada pukul 20.00 sampai menjelang Jam Malam', '2018-08-17', 'non_event', 1, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (68, 'Pelatihan Kepemimpinan Mahasiswa Prodi Bersama (PKMPB) ', 'Acara pelatihan kepemimpinan untuk mahasiswa ilmu komputer', '2018-09-17', 'event', 1, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (69, 'Mading', '-', '2018-09-17', 'non_event', 1, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (70, 'Reminder Hari X ', '-', '2018-09-17', 'non_event', 1, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (71, 'Pelatihan Website', 'Pelatihan pembuatan website bagi prodi ilmu komputer', '2018-09-17', 'non_event', 1, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (72, 'Gathering Ilkom', 'Kumpul bersama dengan mahasiswa dan alumni ilmu komputer', '2018-09-17', 'non_event', 1, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (73, ' Sosmed Maintenance', '-', '2018-09-17', 'non_event', 1, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (74, 'GRAFIC (Gema Ramadhan From Mathematic) ', '\r\n Bulan ramadhan ialah bulan yang penuh dengan berkah. maka dari itu dept cosmic mengajak civitas akademika rumpun matematika untuk menyemarakkan ramadhan dengan menyelenggarakan agenda kebaikan bernama GRAFIC (Gema Ramadhan From Mathematic).  ', '2018-06-08', 'event', 1, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (75, 'BAPER (Buka Puasa Bareng Ilmu Komputer) ', 'Agenda BAPER adalah agenda yang mirip dengan GRAFIC namun agenda ini lebih dibatasi pada civitas akademika Ilmu Komputer saja', '0000-00-00', 'non_event', 1, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (76, 'Majalah Dinding (Mading)', 'Mading ini bertempat di Musholla Al-Khawarizmi di Gedung Dewi Sartika Lantai 5. Alhamdulillah selama 1 periode ini, kami sudah membuat 1 tema mading yaitu “Saatnya Move On” di bulan Januari 2019 H', '0000-00-00', 'non_event', 1, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (77, 'KABAR (Kajian Bareng Ilmu Komputer)', '\r\n KABAR berbentuk taujih yang mana tema dari taujih tersebut ditentukan oleh kelas Ilmu Komputer yang ditunjuk, dan dilaksanakan oleh departemen cosmic', '0000-00-00', 'non_event', 1, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (78, 'HTML (Hadist, Tausiyah, Motivasi, dan La Tansa)', '\r\n HTML berbentuk elektronik (jarkoman) alhamdulillah sudah kami jalankan di setiap kamisnya sesuai kesepakatan Aliansi Dakwah FMIPA walau tidak berjalan dengan baik agar tiap harinya selalu ada tausiyah dari rohis jurusan maupun LD MUA dan dengan itu HTML dapat tersebar lebih luas ke segala jurusan bahklan lebih luas lagi, begitu juga dengan tausiyah rohis jurusan lainnya dan LD MUA', '0000-00-00', 'non_event', 1, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (79, 'Pra Rapat Koordinasi', 'rapat pertama bersama BEM prodi', '0000-00-00', 'non_event', 2, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (80, 'Rapat Koordinasi', 'rapat bersama BEM prodi', '0000-00-00', 'non_event', 2, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (81, 'Pra Rapat Kerja Bersama', 'rapat bersama BEM prodi', '0000-00-00', 'non_event', 2, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (82, 'Rapat Kerja Bersama', 'rapat bersama BEM prodi', '0000-00-00', 'non_event', 2, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (83, 'Rapat Pimpinan', 'rapat bersama pimpinan BEM prodi', '0000-00-00', 'non_event', 2, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (84, 'Rapat Komisi', 'rapat bersama perwakilan setiap departemen BEM prodi', '0000-00-00', 'non_event', 2, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (85, 'Rapat Koordinasi Bamus', '-', '0000-00-00', 'non_event', 2, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (86, 'Rapat Dengar Pendapat', 'Rapat Bersama BEM prodi', '0000-00-00', 'non_event', 2, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (87, 'Sidang Umum', 'Sidang untuk membicarakan pertanggungjawaban pada kepengurusan Opmawa periode 2018-2019', '0000-00-00', 'non_event', 2, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (88, 'Sidang Pleno', '-', '0000-00-00', 'non_event', 2, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (89, 'Tanda Bukti Penerimaan Proposal atau LPJ', 'Bukti bahwa BEM prodi telah memberikan/menyerahkan proposal/LPJ kepada LLM prodi', '0000-00-00', 'non_event', 2, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (91, 'Kajian Legislatif', 'Seminar tentang kelegislatifan', '2018-01-01', 'event', 2, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (92, 'Open House Legislatif', 'Open house untuk lebih mengenal lebih tentang kelegislatifan', '2018-01-01', 'event', 2, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (93, 'Komisi Pemilihan Umum', 'Pemilu untuk menentukan kepengurusan Opmawa pada periode berikutnya', '2018-01-01', 'event', 2, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (94, 'TIPE MPA FMIPA', 'Pengawasan MPA yang dilakukan saat pengenalan lingkungan akademik kepada mahasiswa baru, bekerja sama dengan BPM fakultas', '2018-01-01', 'event', 2, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (95, 'Kotak Aspirasi', 'Wadah berupa kotak saran yang berisi aspirasi dari mahasiswa', '2018-01-01', 'non_event', 2, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (96, 'Legislatif News', '-', '2018-01-01', 'non_event', 2, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (97, 'Jaring Aspirasi (Angket)', 'Penyebaran angket untuk mendapatkan aspirasi dari mahasiswa', '2018-01-01', 'non_event', 2, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (98, 'Studi Banding Legislatif', 'Silaturahmi dengan legislatif di prodi lain', '2018-01-01', 'non_event', 2, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (99, 'Family Day LLM', '-', '2018-01-01', 'non_event', 2, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (100, 'Birthday Alert', '-', '2018-01-01', 'non_event', 2, 2018, NULL, NULL, 2);
INSERT INTO `proker_tbl` (`proker_ID`, `proker_nama`, `proker_deskripsi`, `proker_tanggal`, `proker_jenis`, `proker_lembaga`, `proker_tahun`, `proker_nilai`, `proker_output`, `id_opmawa`) VALUES (101, 'Sosial Media', '-', '2018-01-01', 'non_event', 2, 2018, NULL, NULL, 2);


#
# TABLE STRUCTURE FOR: prokeranggota_tbl
#

DROP TABLE IF EXISTS `prokeranggota_tbl`;

CREATE TABLE `prokeranggota_tbl` (
  `prokerAnggota_ID` int(11) NOT NULL AUTO_INCREMENT,
  `id_proker` int(11) NOT NULL,
  `id_posisi` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  PRIMARY KEY (`prokerAnggota_ID`),
  KEY `proker` (`id_proker`),
  KEY `posisi` (`id_posisi`),
  KEY `nama` (`id_user`),
  CONSTRAINT `nama` FOREIGN KEY (`id_user`) REFERENCES `user_tbl` (`user_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `posisi` FOREIGN KEY (`id_posisi`) REFERENCES `prokerposisi_tbl` (`prokerPosisi_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `proker` FOREIGN KEY (`id_proker`) REFERENCES `proker_tbl` (`proker_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=latin1;

INSERT INTO `prokeranggota_tbl` (`prokerAnggota_ID`, `id_proker`, `id_posisi`, `id_user`) VALUES (26, 12, 85, 33);
INSERT INTO `prokeranggota_tbl` (`prokerAnggota_ID`, `id_proker`, `id_posisi`, `id_user`) VALUES (27, 13, 86, 40);
INSERT INTO `prokeranggota_tbl` (`prokerAnggota_ID`, `id_proker`, `id_posisi`, `id_user`) VALUES (28, 14, 87, 33);
INSERT INTO `prokeranggota_tbl` (`prokerAnggota_ID`, `id_proker`, `id_posisi`, `id_user`) VALUES (29, 15, 88, 36);
INSERT INTO `prokeranggota_tbl` (`prokerAnggota_ID`, `id_proker`, `id_posisi`, `id_user`) VALUES (30, 16, 89, 34);
INSERT INTO `prokeranggota_tbl` (`prokerAnggota_ID`, `id_proker`, `id_posisi`, `id_user`) VALUES (31, 17, 90, 33);
INSERT INTO `prokeranggota_tbl` (`prokerAnggota_ID`, `id_proker`, `id_posisi`, `id_user`) VALUES (32, 12, 92, 45);
INSERT INTO `prokeranggota_tbl` (`prokerAnggota_ID`, `id_proker`, `id_posisi`, `id_user`) VALUES (33, 56, 93, 95);
INSERT INTO `prokeranggota_tbl` (`prokerAnggota_ID`, `id_proker`, `id_posisi`, `id_user`) VALUES (34, 56, 94, 97);
INSERT INTO `prokeranggota_tbl` (`prokerAnggota_ID`, `id_proker`, `id_posisi`, `id_user`) VALUES (35, 56, 95, 96);
INSERT INTO `prokeranggota_tbl` (`prokerAnggota_ID`, `id_proker`, `id_posisi`, `id_user`) VALUES (36, 56, 95, 98);
INSERT INTO `prokeranggota_tbl` (`prokerAnggota_ID`, `id_proker`, `id_posisi`, `id_user`) VALUES (37, 56, 95, 99);
INSERT INTO `prokeranggota_tbl` (`prokerAnggota_ID`, `id_proker`, `id_posisi`, `id_user`) VALUES (38, 74, 96, 110);
INSERT INTO `prokeranggota_tbl` (`prokerAnggota_ID`, `id_proker`, `id_posisi`, `id_user`) VALUES (39, 74, 97, 111);
INSERT INTO `prokeranggota_tbl` (`prokerAnggota_ID`, `id_proker`, `id_posisi`, `id_user`) VALUES (40, 74, 98, 112);
INSERT INTO `prokeranggota_tbl` (`prokerAnggota_ID`, `id_proker`, `id_posisi`, `id_user`) VALUES (41, 74, 98, 113);
INSERT INTO `prokeranggota_tbl` (`prokerAnggota_ID`, `id_proker`, `id_posisi`, `id_user`) VALUES (42, 64, 99, 100);
INSERT INTO `prokeranggota_tbl` (`prokerAnggota_ID`, `id_proker`, `id_posisi`, `id_user`) VALUES (43, 64, 100, 101);
INSERT INTO `prokeranggota_tbl` (`prokerAnggota_ID`, `id_proker`, `id_posisi`, `id_user`) VALUES (45, 64, 101, 103);
INSERT INTO `prokeranggota_tbl` (`prokerAnggota_ID`, `id_proker`, `id_posisi`, `id_user`) VALUES (46, 64, 101, 104);
INSERT INTO `prokeranggota_tbl` (`prokerAnggota_ID`, `id_proker`, `id_posisi`, `id_user`) VALUES (47, 64, 101, 102);


#
# TABLE STRUCTURE FOR: prokerevaluasi_tbl
#

DROP TABLE IF EXISTS `prokerevaluasi_tbl`;

CREATE TABLE `prokerevaluasi_tbl` (
  `prokerEvaluasi_ID` int(11) NOT NULL AUTO_INCREMENT,
  `id_proker` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `prokerEvaluasi_isi` text NOT NULL,
  PRIMARY KEY (`prokerEvaluasi_ID`),
  KEY `proker-prokerEvaluasi` (`id_proker`),
  KEY `user-prokerEvaluasi` (`id_user`),
  CONSTRAINT `proker-prokerEvaluasi` FOREIGN KEY (`id_proker`) REFERENCES `proker_tbl` (`proker_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user-prokerEvaluasi` FOREIGN KEY (`id_user`) REFERENCES `user_tbl` (`user_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=latin1;

INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (6, 12, 45, 'Kesibukan panitia di luar agenda PKMF, sehingga jarang untuk kumpul yang menyebabkan koordinasi masih kurang baik');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (7, 12, 45, 'Managemen keuangan yang perlu diperkirakan dengan baik agar tidak timbul defisit pada keuangan');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (8, 12, 45, 'Untuk kepanitian kedepan diharapkan selalu berkoordinasi dengan SC atau BEMF dalam hal disini kaderisasi BEMF agar tidak ada Miss Komunikasi');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (9, 12, 45, 'Mempersiapkan segala sesuatu dengan terencana terutama juklak acara sehingga tidak terkesan mendadak dalam menyiapkannya');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (10, 13, 45, 'Peserta yang tidak memenuhi target');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (11, 13, 45, 'Cuaca yang tidak mendukung sehingga beberapa kegiatan tidak terlaksana');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (12, 14, 45, 'Untuk reminder Ulang tahun masih ada beberapa yang terlewat');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (13, 14, 45, 'Serta untuk kabar keluarga yang sakit masih belum terkabar semua, berharap peran delegasi dapat memantau setiap departemennya');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (14, 14, 45, 'Untuk FISI lebih diintensifkan lagi penyebaran jarkomannya ke seluruh anggota BEM FMIPA');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (15, 14, 45, 'Untuk DBD masih sulit dicari orang yang mau dijadikan narasumber, MC, dan moderator');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (16, 15, 45, 'Padatnya jadwal kaderisasi di rumpun sehingga dalam hal menentukan waktu bertemu sedikit terkendala');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (17, 15, 45, 'Tidak semua personil kaderisasi rumpun yang hadir dalam agenda temu sahabat kaderisasi ini');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (18, 15, 45, 'Sampai satu periode ini baru tercapai satu kali temu sahabat kaderisasi se-MIPA');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (19, 16, 45, 'Peserta yang hadir pada SOL sangat tidak mencapai target bahkan SOL tidak dimulai karena sedikitnya peserta yang hadir');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (20, 16, 45, 'Pada saat diadakan banyak agenda lain yang juga diadakan pada waktu yang bersamaan sehingga peserta yang hadir sedikit');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (21, 16, 45, 'Kurangnya persiapan dari departemen Kaderisasi sendiri untuk agenda SOL ini');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (22, 16, 45, 'SOL II tidak terlaksana, SOL III digantikan dengan agenda Upgrading');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (23, 17, 45, 'Akan ada pro dan kontra di setiap rangkaian PKKMB, jadikan ruhiyah yang baik dan perencanaan yang matang sebagai poin utama dalam penyelenggaraan agenda ini');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (24, 17, 45, 'Panitia yang keluar dari kepanitiaan PKKMB');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (25, 17, 45, 'Sarannya lebih banyak melakukan koordinsi baik antara panitia, birokrasi, dan SC');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (26, 28, 69, 'Kehadiran peserta sidang yang minim');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (27, 28, 69, 'Jadwal yang kurang mengakomodir kehadiran');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (28, 28, 69, 'Perlunya pemahaman tentang bahasan sidang');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (29, 28, 69, 'Perlunya pemahaman terkait urgensi dari setiap sidang');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (30, 33, 69, 'Perlu ditambahkan follow up dengan bentuk komunikasi yang berkelanjutan dengan dekanat FMIPA ');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (31, 34, 69, 'Diganti dengan rapat rutin karena jadwal anggota yang padat');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (32, 35, 69, 'Perlu meningkatkan kesadaran antara BPM dengan BEMF dalam menjalankan rapat ini');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (33, 36, 69, 'Jadwal harus mengakomidir kehadiran semua peserta sidang');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (34, 36, 69, 'Perlunya pemahaman terkait urgensi menghadiri sidang pleno');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (35, 38, 69, 'Dalam pelaksanaannya perlu untuk disosialisasikan ke semua anggota BPM FMIPA agar dalam mengawasinya bisa lebih lengkap');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (36, 39, 69, 'Perlu ada persiapan lebih baik');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (37, 40, 69, 'Pembuatan diusahakan diawal kepengurusan sehingga sudah dapat dipakai ketika pertama kali mengawas');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (38, 41, 69, 'Perlu adanya konsistensi dan modifikasi');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (39, 42, 69, 'Perlu adanya penyatuan visi dalam program ini');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (40, 43, 69, 'Jadwal perlu mengakomidir kehadiran peserta');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (41, 44, 69, 'Perlu keistiqomahan dalam memposting');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (42, 44, 69, 'Perlu konsep media yang baku untuk satu periode');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (43, 45, 69, 'BPM FMIPA perlu berperan lebih aktif lagi dalam menjaring aspirasi dan menggalang isu');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (44, 45, 69, 'Lebih luas lagi yang dijadikan pesertanya');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (45, 46, 69, 'Perlu adanya penyatuan visi dalam program ini');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (46, 47, 69, 'Perlu adanya sosialisasi jadwal agar waktunya tidak bentrok');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (47, 48, 69, 'Perlu follow up dan info kepada mahasiswa tentang hasilnya');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (48, 49, 69, 'Kesadaran anggota legislatif masih rendah terkait proses kaderisasi yang berdampak pada terhambatnya kinerja dan perkembangan lembaga');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (49, 50, 69, 'Lebih sering');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (50, 51, 69, 'Pelaksanaannya sudah baik namun perlu disosialisasikan lebih gencar lagi agar banyak anggota legislatif yang hadir');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (51, 52, 69, 'Pelaksanaannya sudah baik namun perlu disosialisasikan lebih gencar lagi agar banyak anggota legislatif yang hadir');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (52, 53, 69, 'Perlu kesadaran dari setiap anggota komisi terkait pentingnya mengawasi BEMF');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (53, 54, 69, 'Perlu dipersiapkan penyelenggara pemilu yang berkualitas');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (54, 55, 45, 'Pundi seharusnya mulai berjalan di bulan Juni hingga Juli untuk termin pertama dan bulan November untuk termin kedua karena pengumpulan dana Pundi satu kali dalam satu semester.');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (55, 55, 45, 'Masih sedikit anggota Departemen Advokasi & Keolahragaan yang ikut serta untuk sosialisasi dan masuk langsung ke kelas-kelas');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (56, 55, 45, 'Untuk pengumpulan termin pertama tidak berjalan, namun pada termin kedua atau semester 109 berjalan. Sehingga perolehan dana Pundi pun bisa dibilang  \r\n\r\n \r\n33 | KABINET PROAKTIF \r\n \r\n \r\n \r\nsedikit jika kita bandingkan dengan yang sebelumnya. Mengingat jumlah mahasiswa dan kebutuhan di Ilmu Komputer cukup banyak. Sangat disayangkan karena belum mampu secara optimal melakukan pengumpulan dana Pundi yang padahal bisa tercukupkan karena jumlah kelas di Ilmu Komputer yang banyak. Untuk selanjutnya coba untuk lebih disiplin dan inisiatif untuk memulai pengumpulan dana Pundi karena mengingat urgensi dana Pundi untuk kesejahteraan mahasiswa. ');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (57, 55, 45, ' kurang aktif untuk mengingatkan agen advor untuk pengumpulan Pundi dan Nadi');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (58, 57, 45, 'Bank Data Mahasiswa berjalan sesuai dengan target yaitu di bulan November 2018. Namun, pelaksanaannya sedikit terlambat dari yang diharapkan, yaitu dimulai dari pertengahan bulan November. Presentase pengisian bank data belum mencapai target yaitu 80% dari mahasiswa angkatan 2016 – 2018. Data yang berhasil dihimpun hanya mencapai kurang dari 50% mahasiswa ilmu komputer. Juga masih ada beberapa anggota Departemen Advokasi & Keolahragaan yang belum mengisi bank data. Juga saat masa bayaran banyak nama-nama pengaduan yang tidak ada data nya di bank data. Sehinga harus menanyakan data nya langsung ke yang bersangkutan. ');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (59, 85, 69, 'Karena kita menunjuk bamus, jadi semua berhak untuk ikut musyawarah ');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (60, 86, 69, 'Perlu adanya kesadaran dari pihak LLM maupun BEM untuk mengadakan rapat ini');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (61, 88, 69, 'Hanya terlaksana sekali, berdasarkan PO seharusnya pertriwulan (3bulan sekali) ');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (62, 89, 69, 'Kurang efektif karena sering tidak dibawa oleh LLM atau lupa diserahkan ketika diterima, ataupun juga karena hanya selembar kertas kecil, maka mudah hilang. ');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (63, 91, 69, 'Terlaksana dua kali sesuai dengan kesepakatan bersama dengan LLMP Ilmu Komputer dan Ilmu Komputer yang masing-masing mendapat kesempatan untuk mengadakan kajian satu kali');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (64, 95, 69, 'Terlaksana satu kali setelah ada mahasiswa baru, satu saat PKKM');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (65, 97, 69, 'Hanya terlaksana saat sidang RKB dan sidang umum ');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (66, 99, 69, 'Diadakan bersama dengan LLMP Matematika dan LLMP Ilmu Komputer ');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (67, 100, 69, 'Kurangnya kesadaran untuk saling mengingatkan dan hanya ketua yang sering mengingatkan melalui Birthday Alert di grup WA');
INSERT INTO `prokerevaluasi_tbl` (`prokerEvaluasi_ID`, `id_proker`, `id_user`, `prokerEvaluasi_isi`) VALUES (68, 101, 69, 'Diharapkan lebih aktif dan rapih dalam setiap postingannya ');


#
# TABLE STRUCTURE FOR: prokerposisi_tbl
#

DROP TABLE IF EXISTS `prokerposisi_tbl`;

CREATE TABLE `prokerposisi_tbl` (
  `prokerPosisi_ID` int(11) NOT NULL AUTO_INCREMENT,
  `id_proker` int(3) NOT NULL,
  `prokerPosisi_nama` varchar(25) NOT NULL,
  PRIMARY KEY (`prokerPosisi_ID`),
  KEY `getProker` (`id_proker`),
  CONSTRAINT `getProker` FOREIGN KEY (`id_proker`) REFERENCES `proker_tbl` (`proker_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=latin1;

INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (85, 12, 'Ketua pelaksana');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (86, 13, 'Ketua pelaksana');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (87, 14, 'Ketua pelaksana');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (88, 15, 'Ketua pelaksana');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (89, 16, 'Ketua pelaksana');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (90, 17, 'Ketua pelaksana');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (91, 26, 'TEST');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (92, 12, 'Administrasi');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (93, 56, 'Ketua Pelaksana');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (94, 56, 'Wakil Ketua Pelaksana');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (95, 56, 'Staff Panitia');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (96, 74, 'Ketua Pelaksana');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (97, 74, 'Wakil Ketua Pelaksana');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (98, 74, 'Staff Panitia');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (99, 64, 'Ketua Pelaksana');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (100, 64, 'Wakil Ketua Pelaksana');
INSERT INTO `prokerposisi_tbl` (`prokerPosisi_ID`, `id_proker`, `prokerPosisi_nama`) VALUES (101, 64, 'Staff Panitia');


#
# TABLE STRUCTURE FOR: prokertugas_tbl
#

DROP TABLE IF EXISTS `prokertugas_tbl`;

CREATE TABLE `prokertugas_tbl` (
  `prokerTugas_ID` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `id_proker` int(11) NOT NULL,
  `prokerTugas_deskripsi` varchar(255) NOT NULL,
  `prokerTugas_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`prokerTugas_ID`),
  KEY `namaUser` (`id_user`),
  KEY `namaProker` (`id_proker`),
  CONSTRAINT `namaProker` FOREIGN KEY (`id_proker`) REFERENCES `proker_tbl` (`proker_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `prokertugas_tbl` (`prokerTugas_ID`, `id_user`, `id_proker`, `prokerTugas_deskripsi`, `prokerTugas_status`) VALUES (1, 45, 12, 'Buat rundown untuk acara', 1);


#
# TABLE STRUCTURE FOR: rapat_tbl
#

DROP TABLE IF EXISTS `rapat_tbl`;

CREATE TABLE `rapat_tbl` (
  `rapat_ID` int(11) NOT NULL AUTO_INCREMENT,
  `rapat_tanggal` date NOT NULL,
  `rapat_deskripsi` varchar(100) NOT NULL,
  `rapat_lembaga` int(11) NOT NULL,
  `id_opmawa` int(11) NOT NULL,
  PRIMARY KEY (`rapat_ID`),
  KEY `getOpmawa_rapat` (`id_opmawa`),
  CONSTRAINT `getOpmawa_rapat` FOREIGN KEY (`id_opmawa`) REFERENCES `opmawa_tbl` (`opmawa_ID`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `rapat_tbl` (`rapat_ID`, `rapat_tanggal`, `rapat_deskripsi`, `rapat_lembaga`, `id_opmawa`) VALUES (1, '2020-01-30', 'Rapat Pembentukan Panitia Seminar', 1, 2);
INSERT INTO `rapat_tbl` (`rapat_ID`, `rapat_tanggal`, `rapat_deskripsi`, `rapat_lembaga`, `id_opmawa`) VALUES (2, '2020-01-24', 'Silaturahmi', 1, 2);
INSERT INTO `rapat_tbl` (`rapat_ID`, `rapat_tanggal`, `rapat_deskripsi`, `rapat_lembaga`, `id_opmawa`) VALUES (3, '2020-01-28', 'Bro', 1, 1);


#
# TABLE STRUCTURE FOR: user_tbl
#

DROP TABLE IF EXISTS `user_tbl`;

CREATE TABLE `user_tbl` (
  `user_ID` int(11) NOT NULL AUTO_INCREMENT,
  `user_nama` varchar(25) NOT NULL,
  `user_NIM` varchar(15) NOT NULL,
  `user_pass` varchar(25) NOT NULL,
  `id_prodi` int(2) NOT NULL,
  `id_posisi` int(2) NOT NULL,
  `id_opmawa` int(11) NOT NULL,
  `id_departemen` int(11) NOT NULL,
  `user_tahun` int(4) NOT NULL,
  `user_role` int(1) NOT NULL,
  PRIMARY KEY (`user_ID`),
  KEY `getPosisi` (`id_posisi`),
  KEY `getDepartemen` (`id_departemen`),
  KEY `getOpmawa` (`id_opmawa`),
  KEY `getProdi` (`id_prodi`),
  CONSTRAINT `getOpmawa` FOREIGN KEY (`id_opmawa`) REFERENCES `opmawa_tbl` (`opmawa_ID`) ON UPDATE CASCADE,
  CONSTRAINT `getProdi` FOREIGN KEY (`id_prodi`) REFERENCES `prodi_tbl` (`prodi_ID`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=latin1;

INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (3, 'Bayu Mukti Sanjoyo ', '3215153254', '3215153254', 12, 1, 1, 1, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (33, 'Wahyu Hutomo', '315151047', '315151047', 1, 3, 1, 15, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (34, 'Andi Ilham Razak', '9090909090', '9090909090', 12, 4, 1, 15, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (35, 'M. Fadhil Haritsah ', '9090909090', '9090909090', 12, 4, 1, 15, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (36, 'Citra Fatmala', '9090909090', '9090909090', 12, 4, 1, 15, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (37, 'Assofa Maria', '9090909090', '9090909090', 10, 4, 1, 15, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (38, 'Ulan Al Ismu', '9090909090', '9090909090', 10, 4, 1, 15, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (39, 'Mutiara Chaerunnisa', '9090909090', '9090909090', 9, 4, 1, 15, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (40, 'Linda Astuti', '9090909090', '9090909090', 13, 4, 1, 15, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (41, 'Refani Izqi L', '9090909090', '9090909090', 13, 4, 1, 15, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (42, 'Nurul Thaniya S', '9090909090', '9090909090', 1, 4, 1, 15, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (43, 'Mithalia Nour S', '9090909090', '9090909090', 5, 4, 1, 15, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (44, 'Monica Ratna A', '9090909090', '9090909090', 6, 4, 1, 15, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (45, 'Master EKSEKUTIF', '1', '1', 6, 1, 2, 1, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (46, 'Tri Setiyoto', '3325152952 ', '3325152952 ', 10, 3, 1, 16, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (47, 'Jorgi Sanjaya', '9090909090', '9090909090', 10, 4, 1, 16, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (48, 'Hanan Nurrohman', '9090909090', '9090909090', 10, 4, 1, 16, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (49, 'Susi Rahmiyati', '9090909090', '9090909090', 10, 4, 1, 16, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (50, 'Filadelfia R', '9090909090', '9090909090', 10, 4, 1, 16, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (51, 'Faizah Nurwita', '9090909090', '9090909090', 1, 4, 1, 16, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (52, 'Selfista Maria E', '9090909090', '9090909090', 1, 4, 1, 16, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (53, 'Adi Bangga Wijaya', '9090909090', '9090909090', 1, 4, 1, 16, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (54, 'Assita Wahyu A', '9090909090', '9090909090', 1, 4, 1, 16, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (55, 'Nurul Avita Sari', '9090909090', '9090909090', 1, 4, 1, 16, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (56, 'Radina Hanifah', '9090909090', '9090909090', 1, 4, 1, 16, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (57, 'Wisnu Adi Nugroho', '3325152960 ', '3325152960 ', 1, 3, 1, 17, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (58, 'Dini Fitria', '9090909090', '9090909090', 5, 4, 1, 17, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (59, 'Rainy Suluya', '9090909090', '9090909090', 5, 4, 1, 17, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (60, 'Chika Annisa', '9090909090', '9090909090', 5, 4, 1, 17, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (61, 'Nuurur Risqa Aliya', '9090909090', '9090909090', 5, 4, 1, 17, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (62, 'M. Irfany Ananda', '9090909090', '9090909090', 1, 4, 1, 17, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (63, 'Nadhirah', '9090909090', '9090909090', 1, 4, 1, 17, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (64, 'Nur Eka', '9090909090', '9090909090', 1, 4, 1, 17, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (65, 'Widuri', '9090909090', '9090909090', 1, 4, 1, 17, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (66, 'Anas Sadewo', '9090909090', '9090909090', 9, 5, 1, 17, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (67, 'Robby Haryanto', '9090909090', '9090909090', 9, 5, 1, 17, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (68, 'Widuri Andriana', '9090909090', '9090909090', 9, 5, 1, 17, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (69, 'master LEGISLATIF', '2', '2', 6, 1, 2, 1, 2018, 2);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (70, 'Dhia Rahid', '3415150424', '3415150424', 12, 2, 1, 1, 2018, 2);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (71, 'Noer Syahbani', '1308617029', '1308617029', 10, 8, 1, 1, 2018, 2);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (72, 'Fauzan Nur Fahlurrahman', '3415163523', '3415163523', 12, 8, 1, 1, 2018, 2);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (73, 'Fadhillah Arifin', '3315160803', '3315160803', 13, 8, 1, 1, 2018, 2);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (74, 'Agung Aji Saputro', '3225161085', '3225161085', 8, 8, 1, 1, 2018, 2);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (75, 'Nur Devi Vani', '3215150734', '3215150734', 9, 8, 1, 1, 2018, 2);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (76, 'Devy Retnosari', '3125163412', '3125163412', 5, 8, 1, 1, 2018, 2);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (77, 'Dickny Asti Khaerunisa', '3415150782', '3415150782', 12, 9, 1, 1, 2018, 2);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (78, 'Zico Arman', '34251613174', '34251613174', 10, 6, 1, 15, 2018, 2);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (79, 'Maghfirah Idzati Aulia', '3415160162', '3415160162', 12, 6, 1, 12, 2018, 2);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (80, 'Dessy Putriana Sari', '3425161134', '3425161134', 10, 6, 1, 15, 2018, 2);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (81, 'Wahdivati Laisa A.P', '3315160416', '3315160416', 13, 6, 1, 13, 2018, 2);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (82, 'Rosita Ayu M', '1212121212', '1212121212', 10, 12, 1, 17, 2018, 2);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (83, 'Allika Firhandini', '1212121212', '1212121212', 10, 7, 1, 16, 2018, 2);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (84, 'Nina Deslina', '1212121212', '1212121212', 12, 7, 1, 14, 2018, 2);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (85, 'Elsa Oktaviani', '1212121212', '1212121212', 9, 7, 1, 15, 2018, 2);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (86, 'Bella Octavia', '1212121212', '1212121212', 5, 7, 1, 14, 2018, 2);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (87, 'Auzan Asyraf', '1212121212', '1212121212', 7, 7, 1, 17, 2018, 2);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (88, 'Athiyyah Afifah', '1212121212', '1212121212', 7, 7, 1, 13, 2018, 2);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (89, 'Master DOSEN', '1', '3', 6, 1, 2, 1, 2018, 0);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (92, 'Febrian Abdul Fatah', '3145161578-2018', '3145161578', 6, 1, 2, 22, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (93, 'Farah Ayu Anandita', '3145160616', '3145160616 ', 6, 16, 2, 22, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (94, 'Dwi Solihatun', '3145161574', '3145161574 ', 6, 17, 2, 22, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (95, 'Dwi Aryanto Dio Wicaksono', '3145161971 ', '3145161971 ', 6, 3, 2, 25, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (96, 'Fathurrahman Ikhsan', '3030', '3030', 6, 4, 2, 25, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (97, 'Ilham Arrosyid', '3030', '3030', 6, 4, 2, 25, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (98, 'Ivan Adi Putra', '3030', '3030', 6, 4, 2, 25, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (99, 'Octanina Salsabila', '3030', '3030', 6, 4, 2, 25, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (100, 'Aina Indah Lestari', '3145163237 ', '3145163237 ', 6, 3, 2, 26, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (101, 'Maldini Abdillah', '3030 ', '3030', 6, 4, 2, 26, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (102, 'Yoppi Prasetya Saputra', '3030 ', '3030', 6, 4, 2, 26, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (103, 'Maura Qoonitah Putri', '3030 ', '3030', 6, 4, 2, 26, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (104, 'Togu Annaaf Kumara', '3030 ', '3030', 6, 4, 2, 26, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (105, 'Anjar Mursyidi', '3145164245', '3145164245 ', 6, 3, 2, 27, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (106, ' Muhammad Hafidz Oktaneva', '3030', '3030', 6, 4, 2, 27, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (107, 'Muhammad Aufi Rayesa', '3030', '3030', 6, 4, 2, 27, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (108, 'Aty Lestari', '3030', '3030', 6, 4, 2, 27, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (109, 'Berilya Imandika', '3030', '3030', 6, 4, 2, 27, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (110, 'Muhammad Insan Khamil', '3145161580', '3145161580 ', 6, 3, 2, 28, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (111, ' Faqihuddin Al Farisi', '3030', '3030', 6, 4, 2, 28, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (112, 'Faiz Akmal', '3030', '3030', 6, 4, 2, 28, 2018, 1);
INSERT INTO `user_tbl` (`user_ID`, `user_nama`, `user_NIM`, `user_pass`, `id_prodi`, `id_posisi`, `id_opmawa`, `id_departemen`, `user_tahun`, `user_role`) VALUES (113, 'Muhammad Aziz Nurhikmah', '3030', '3030', 6, 4, 2, 28, 2018, 1);


